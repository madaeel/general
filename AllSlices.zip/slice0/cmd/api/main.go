package main

import (
	"log"
	"os"

	"vespucci/internal/config"
	"vespucci/internal/http"
)

func main() {
	cfg := config.Load()

	r := http.NewRouter(cfg)

	port := cfg.Port
	if port == "" {
		port = "8080"
	}

	if err := r.Run(":" + port); err != nil {
		log.Fatalf("server failed: %v", err)
		os.Exit(1)
	}
}
