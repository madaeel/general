package config

import (
	"os"
)

type Config struct {
	Port             string
	DatabaseURL      string
	PostmarkAPIKey   string
	GoogleClientID   string
	GoogleSecret     string
	FacebookClientID string
	FacebookSecret   string
}

func Load() *Config {
	return &Config{
		Port:             getEnv("PORT", "8080"),
		DatabaseURL:      getEnv("DATABASE_URL", "postgres://user:pass@localhost:5432/vespucci?sslmode=disable"),
		PostmarkAPIKey:   getEnv("POSTMARK_API_KEY", ""),
		GoogleClientID:   getEnv("GOOGLE_CLIENT_ID", ""),
		GoogleSecret:     getEnv("GOOGLE_SECRET", ""),
		FacebookClientID: getEnv("FACEBOOK_CLIENT_ID", ""),
		FacebookSecret:   getEnv("FACEBOOK_SECRET", ""),
	}
}

func getEnv(key, fallback string) string {
	if val, ok := os.LookupEnv(key); ok {
		return val
	}
	return fallback
}
