package http

import (
	stdhttp "net/http"

	"github.com/gin-gonic/gin"
	"vespucci/internal/config"
)

func NewRouter(cfg *config.Config) *gin.Engine {
	r := gin.New()

	// Middlewares
	r.Use(RequestIDMiddleware())
	r.Use(LoggerMiddleware())
	r.Use(RecoveryMiddleware())

	// Health endpoint
	r.GET("/health", func(c *gin.Context) {
		c.JSON(stdhttp.StatusOK, gin.H{"ok": true})
	})

	return r
}
