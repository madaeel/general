package main

import (
	"log"
	"os"
	"time"

	"vespucci/internal/config"
	"vespucci/internal/http"
	"vespucci/internal/migrate"
	"vespucci/internal/store"
)

func main() {
	cfg := config.Load()

	// Optional DB connection and migrations
	var pg *store.PGStore
	if cfg.DatabaseURL != "" {
		s, err := store.NewPostgresStore(cfg.DatabaseURL, store.DBPool{
			MaxOpen:     cfg.DBMaxOpen,
			MaxIdle:     cfg.DBMaxIdle,
			MaxLifetime: cfg.DBConnMaxLifetime,
		})
		if err != nil {
			log.Fatalf("db connect failed: %v", err)
		}
		pg = s
		if cfg.MigrateOnStart {
			if err := migrate.Up(cfg.DatabaseURL, "migrations", 30*time.Second); err != nil {
				log.Fatalf("migrate up failed: %v", err)
			}
		}
		defer pg.Close()
	}

	r := http.NewRouter(cfg)

	port := cfg.Port
	if port == "" {
		port = "8080"
	}

	if err := r.Run(":" + port); err != nil {
		log.Fatalf("server failed: %v", err)
	}
}
