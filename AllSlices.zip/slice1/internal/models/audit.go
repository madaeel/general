package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/datatypes"
)

type AuditEvent struct {
	ID        int64          `gorm:"primaryKey;autoIncrement"`
	UserID    *uuid.UUID     `gorm:"type:uuid"`
	EventType string         `gorm:"type:text;not null"`
	Metadata  datatypes.JSON `gorm:"type:jsonb;not null;default:'{}'"`
	CreatedAt time.Time      `gorm:"type:timestamptz;not null;default:now();index"`
}
