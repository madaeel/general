package models

import (
	"strings"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type User struct {
	ID             uuid.UUID  `gorm:"type:uuid;default:gen_random_uuid();primaryKey"`
	Email          *string    `gorm:"type:citext"`
	EmailNormalized *string   `gorm:"type:citext;uniqueIndex"`
	DisplayName    string     `gorm:"type:text;not null;default:''"`
	CreatedAt      time.Time  `gorm:"type:timestamptz;not null;default:now()"`
	UpdatedAt      time.Time  `gorm:"type:timestamptz;not null;default:now()"`
	LastLoginAt    *time.Time `gorm:"type:timestamptz"`
	IsDisabled     bool       `gorm:"not null;default:false;index"`

	Identities []Identity `gorm:"constraint:OnDelete:CASCADE"`
}

func (u *User) BeforeSave(tx *gorm.DB) error {
	if u.Email != nil {
		v := strings.ToLower(strings.TrimSpace(*u.Email))
		u.EmailNormalized = &v
	} else {
		u.EmailNormalized = nil
	}
	return nil
}
