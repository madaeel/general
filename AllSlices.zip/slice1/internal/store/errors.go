package store

import "errors"

var (
	// Generic sentinel errors for enumeration-safe handling at higher layers
	ErrNotFound        = errors.New("not found")
	ErrConflict        = errors.New("conflict")
	ErrInvalid         = errors.New("invalid")
	ErrOperationFailed = errors.New("operation failed")
)
