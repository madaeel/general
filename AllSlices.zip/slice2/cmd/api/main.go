
package main

import (
	"log"
	"time"

	"github.com/gin-gonic/gin"
	"vespucci/internal/config"
	apphttp "vespucci/internal/http"
	"vespucci/internal/http/handlers"
	"vespucci/internal/mailer"
	"vespucci/internal/migrate"
	"vespucci/internal/security"
	"vespucci/internal/store"
)

func main() {
	cfg := config.Load()

	// Optional DB connection and migrations
	var pg *store.PGStore
	if cfg.DatabaseURL != "" {
		s, err := store.NewPostgresStore(cfg.DatabaseURL, store.DBPool{
			MaxOpen:     cfg.DBMaxOpen,
			MaxIdle:     cfg.DBMaxIdle,
			MaxLifetime: cfg.DBConnMaxLifetime,
		})
		if err != nil {
			log.Fatalf("db connect failed: %v", err)
		}
		pg = s
		if cfg.MigrateOnStart {
			if err := migrate.Up(cfg.DatabaseURL, "migrations", 30*time.Second); err != nil {
				log.Fatalf("migrate up failed: %v", err)
			}
		}
		defer pg.Close()
	}

	// Build router
	var r *gin.Engine
	if pg != nil {
		// Mailer
		var m mailer.Mailer = mailer.NewNoop()
		if cfg.PostmarkAPIKey != "" {
			m = mailer.NewPostmark(cfg.PostmarkAPIKey, cfg.PostmarkFrom, cfg.PostmarkTemplateVerify)
		}
		// TTL and rate limit
		ttl, err := time.ParseDuration(cfg.EmailVerifyTTL)
		if err != nil {
			ttl = 30 * time.Minute
		}
		rl := security.NewRateLimiter(cfg.RateEmailPerHour, cfg.RateIPPerHour, time.Hour)
		// Argon params
		params := security.Argon2Params{
			Time:    cfg.ArgonTime,
			Memory:  cfg.ArgonMemoryMB * 1024,
			Threads: uint8(cfg.ArgonThreads),
			KeyLen:  uint32(cfg.ArgonKeyLen),
		}
		r = apphttp.NewRouterWithDeps(cfg, handlers.Deps{
			Store:       pg,
			Mailer:      m,
			VerifyTTL:   ttl,
			RateLimiter: rl,
			ArgonParams: params,
			BaseURL:     cfg.BaseURL,
		})
	} else {
		r = apphttp.NewRouter(cfg)
	}

	port := cfg.Port
	if port == "" {
		port = "8080"
	}

	if err := r.Run(":" + port); err != nil {
		log.Fatalf("server failed: %v", err)
	}
}
