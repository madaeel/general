
package main

import (
	"flag"
	"fmt"
	"time"

	"vespucci/internal/migrate"
)

func main() {
	url := flag.String("url", "", "DATABASE_URL")
	dir := flag.String("dir", "migrations", "migrations dir")
	direction := flag.String("direction", "up", "up or down")
	timeout := flag.Duration("timeout", 30*time.Second, "timeout")
	flag.Parse()

	if *url == "" {
		panic("-url is required")
	}

	var err error
	if *direction == "up" {
		err = migrate.Up(*url, *dir, *timeout)
	} else if *direction == "down" {
		err = migrate.Down(*url, *dir, *timeout)
	} else {
		panic("unknown direction: " + *direction)
	}
	if err != nil {
		panic(fmt.Sprintf("migration failed: %v", err))
	}
}
