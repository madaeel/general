
package config

import (
	"fmt"
	"os"
)

type Config struct {
	Port              string
	DatabaseURL       string
	PostmarkAPIKey    string
	GoogleClientID    string
	GoogleSecret      string
	FacebookClientID  string
	FacebookSecret    string
	DBMaxOpen         int
	DBMaxIdle         int
	DBConnMaxLifetime string
	MigrateOnStart    bool
	// Email verification and mailer
	EmailVerifyTTL         string
	BaseURL                string
	PostmarkFrom           string
	PostmarkTemplateVerify string
	// Argon2id params
	ArgonTime     int
	ArgonMemoryMB int
	ArgonThreads  int
	ArgonKeyLen   int
	// Rate limits
	RateEmailPerHour int
	RateIPPerHour    int
}

func Load() *Config {
	return &Config{
		Port:               getEnv("PORT", "8080"),
		DatabaseURL:        getEnv("DATABASE_URL", "postgres://user:pass@localhost:5432/vespucci?sslmode=disable"),
		PostmarkAPIKey:     getEnv("POSTMARK_API_KEY", ""),
		GoogleClientID:     getEnv("GOOGLE_CLIENT_ID", ""),
		GoogleSecret:       getEnv("GOOGLE_SECRET", ""),
		FacebookClientID:   getEnv("FACEBOOK_CLIENT_ID", ""),
		FacebookSecret:     getEnv("FACEBOOK_SECRET", ""),
		DBMaxOpen:          getEnvInt("DB_MAX_OPEN", 25),
		DBMaxIdle:          getEnvInt("DB_MAX_IDLE", 5),
		DBConnMaxLifetime:  getEnv("DB_CONN_MAX_LIFETIME", "30m"),
		MigrateOnStart:     getEnvBool("MIGRATE_ON_START", false),
		EmailVerifyTTL:     getEnv("EMAIL_VERIFY_TTL", "30m"),
		BaseURL:            getEnv("BASE_URL", "http://localhost:5173"),
		PostmarkFrom:       getEnv("POSTMARK_FROM", "noreply@example.com"),
		PostmarkTemplateVerify: getEnv("POSTMARK_TEMPLATE_VERIFY", ""),
		ArgonTime:          getEnvInt("ARGON_TIME", 1),
		ArgonMemoryMB:      getEnvInt("ARGON_MEMORY", 64),
		ArgonThreads:       getEnvInt("ARGON_THREADS", 2),
		ArgonKeyLen:        getEnvInt("ARGON_KEYLEN", 32),
		RateEmailPerHour:   getEnvInt("RATE_EMAIL_PER_HOUR", 5),
		RateIPPerHour:      getEnvInt("RATE_IP_PER_HOUR", 20),
	}
}

func getEnv(key, fallback string) string {
	if val, ok := os.LookupEnv(key); ok {
		return val
	}
	return fallback
}

func getEnvInt(key string, fallback int) int {
	if val, ok := os.LookupEnv(key); ok {
		var n int
		_, err := fmt.Sscanf(val, "%d", &n)
		if err == nil {
			return n
		}
	}
	return fallback
}

func getEnvBool(key string, fallback bool) bool {
	if val, ok := os.LookupEnv(key); ok {
		switch val {
		case "1", "true", "TRUE", "True", "yes", "YES", "on", "ON":
			return true
		case "0", "false", "FALSE", "False", "no", "NO", "off", "OFF":
			return false
		}
	}
	return fallback
}
