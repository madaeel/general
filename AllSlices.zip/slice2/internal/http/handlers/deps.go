
package handlers

import (
	"context"
	"time"

	"github.com/google/uuid"
	"vespucci/internal/models"
)

// Store is the minimal repo surface these handlers require.
type Store interface {
	CreateEmailVerification(ctx context.Context, v *models.EmailVerification) error
	ConsumeEmailVerification(ctx context.Context, tokenHash []byte, now time.Time) (string, error)
	FindUserByEmailNormalized(ctx context.Context, emailNorm string) (*models.User, error)
	CreateUser(ctx context.Context, u *models.User) error
	UpsertUserCredentialArgon2id(ctx context.Context, userID uuid.UUID, hash string) error
}
