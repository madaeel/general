
package handlers

import (
	"time"

	"github.com/gin-gonic/gin"
	"vespucci/internal/models"
	"vespucci/internal/security"
)

func MountRegister(r *gin.Engine, d Deps) {
	r.POST("/auth/register", func(c *gin.Context) {
		if d.Store == nil {
			c.JSON(400, gin.H{"error": "invalid_request"})
			return
		}
		var req struct {
			Email    string `json:"email"`
			Password string `json:"password"`
		}
		if err := c.ShouldBindJSON(&req); err != nil || len(req.Password) < 8 || len(req.Password) > 128 {
			c.JSON(400, gin.H{"error": "invalid_request"})
			return
		}
		// enumeration-safe behavior: create user if not found
		u, err := d.Store.FindUserByEmailNormalized(c.Request.Context(), req.Email)
		if err != nil || u == nil {
			u = &models.User{DisplayName: "", Email: &req.Email}
			if err := d.Store.CreateUser(c.Request.Context(), u); err != nil {
				c.JSON(400, gin.H{"error": "invalid_request"})
				return
			}
		}
		// Hash password
		salt, err := security.GenerateToken(16)
		if err != nil {
			c.JSON(400, gin.H{"error": "invalid_request"})
			return
		}
		hash, err := security.Argon2idHash([]byte(req.Password), d.ArgonParams, salt)
		if err != nil {
			c.JSON(400, gin.H{"error": "invalid_request"})
			return
		}
		if err := d.Store.UpsertUserCredentialArgon2id(c.Request.Context(), u.ID, hash); err != nil {
			c.JSON(400, gin.H{"error": "invalid_request"})
			return
		}
		_ = time.Now() // reserved for future audit usage
		c.JSON(200, gin.H{"status": "registered"})
	})
}
