
package handlers_test

import (
	"bytes"
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"vespucci/internal/http/handlers"
	"vespucci/internal/models"
	"vespucci/internal/security"
)

type regStore struct {
	u *models.User
}

func (s *regStore) FindUserByEmailNormalized(ctx context.Context, email string) (*models.User, error) {
	if s.u == nil {
		return nil, nil
	}
	return s.u, nil
}
func (s *regStore) CreateUser(ctx context.Context, u *models.User) error { s.u = u; return nil }
func (s *regStore) UpsertUserCredentialArgon2id(ctx context.Context, id uuid.UUID, hash string) error {
	return nil
}
// Unused here but required by interface
func (s *regStore) CreateEmailVerification(ctx context.Context, v *models.EmailVerification) error { return nil }
func (s *regStore) ConsumeEmailVerification(ctx context.Context, h []byte, now time.Time) (string, error) {
	return "", nil
}

func TestRegisterBasic(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	deps := handlers.Deps{
		Store:       &regStore{},
		VerifyTTL:   30 * time.Minute,
		RateLimiter: security.NewRateLimiter(5, 20, time.Hour),
		ArgonParams: security.Argon2Params{Time: 1, Memory: 64 * 1024, Threads: 2, KeyLen: 32},
	}
	handlers.MountRegister(r, deps)
	w := httptest.NewRecorder()
	req, _ := http.NewRequest("POST", "/auth/register", bytes.NewBufferString(`{"email":"a@example.com","password":"P@ssword123"}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)
	if w.Code != 200 {
		t.Fatalf("expected 200, got %d", w.Code)
	}
}
