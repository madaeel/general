
package handlers

import (
	"encoding/base64"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"vespucci/internal/security"
)

func init() {}

func MountVerificationComplete(r *gin.Engine, d Deps) {
	r.POST("/auth/verification/complete", func(c *gin.Context) {
		var req struct{ Token string `json:"token"` }
		if err := c.ShouldBindJSON(&req); err != nil || req.Token == "" || d.Store == nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid_request"})
			return
		}
		raw, err := base64.RawURLEncoding.DecodeString(req.Token)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid_request"})
			return
		}
		email, err := d.Store.ConsumeEmailVerification(c.Request.Context(), security.HashTokenSHA256(raw), time.Now())
		if err != nil || email == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid_request"})
			return
		}
		c.JSON(http.StatusOK, gin.H{"status": "verified"})
	})
}
