
package handlers_test

import (
	"bytes"
	"context"
	"encoding/base64"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"vespucci/internal/http/handlers"
	"vespucci/internal/models"
)

type consumeOKStore struct{}
func (s *consumeOKStore) ConsumeEmailVerification(ctx context.Context, h []byte, now time.Time) (string, error) {
	return "a@example.com", nil
}
func (s *consumeOKStore) CreateEmailVerification(ctx context.Context, v *models.EmailVerification) error { return nil }
func (s *consumeOKStore) FindUserByEmailNormalized(ctx context.Context, email string) (*models.User, error) { return nil, nil }
func (s *consumeOKStore) CreateUser(ctx context.Context, u *models.User) error { return nil }
func (s *consumeOKStore) UpsertUserCredentialArgon2id(ctx context.Context, id uuid.UUID, hash string) error { return nil }

func TestVerificationCompleteHappyPath(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	token := []byte{1,2,3}
	deps := handlers.Deps{
		Store:     &consumeOKStore{},
		VerifyTTL: 30 * time.Minute,
	}
	handlers.MountVerificationComplete(r, deps)
	w := httptest.NewRecorder()
	body := `{"token":"` + base64.RawURLEncoding.EncodeToString(token) + `"}`
	req, _ := http.NewRequest("POST", "/auth/verification/complete", bytes.NewBufferString(body))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)
	if w.Code != 200 {
		t.Fatalf("expected 200, got %d", w.Code)
	}
}
