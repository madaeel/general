
package handlers

import (
	"encoding/base64"
	"net/http"
	"net/url"
	"time"

	"github.com/gin-gonic/gin"
	"vespucci/internal/models"
	"vespucci/internal/mailer"
	"vespucci/internal/security"
)

type Deps struct {
	Store       Store
	Mailer      mailer.Mailer
	VerifyTTL   time.Duration
	RateLimiter *security.RateLimiter
	ArgonParams security.Argon2Params
	BaseURL     string
}

func Mount(r *gin.Engine, d Deps) {
	r.POST("/auth/verification/start", func(c *gin.Context) {
		var req struct{ Email string `json:"email"` }
		if err := c.ShouldBindJSON(&req); err != nil || req.Email == "" {
			c.JSON(http.StatusOK, gin.H{"status": "ok"}) // enumeration-safe
			return
		}
		ip := c.ClientIP()
		now := time.Now()
		if d.RateLimiter != nil && !d.RateLimiter.Allow(req.Email, ip, now) {
			c.JSON(http.StatusTooManyRequests, gin.H{"error": "invalid_request"})
			return
		}
		// Create token + store hash
		token, err := security.GenerateToken(32)
		if err == nil && d.Store != nil {
			hash := security.HashTokenSHA256(token)
			_ = d.Store.CreateEmailVerification(c.Request.Context(), &models.EmailVerification{
				Email:     req.Email,
				Purpose:   "register",
				TokenHash: hash,
				ExpiresAt: now.Add(d.VerifyTTL),
			})
			if d.Mailer != nil {
				link := d.BaseURL
				if link == "" {
					link = "http://localhost:5173"
				}
				// Provide token to front-end URL; app will POST to complete endpoint
				link = link + "/verify?token=" + url.QueryEscape(base64.RawURLEncoding.EncodeToString(token))
				_ = d.Mailer.SendVerificationEmail(c.Request.Context(), req.Email, link)
			}
		}
		c.JSON(http.StatusOK, gin.H{"status": "ok"})
	})
}
