
package handlers_test

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"vespucci/internal/http/handlers"
	"vespucci/internal/security"
)

func TestVerificationStartEnumerationSafetyAndRateLimit(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	deps := handlers.Deps{
		Store:       nil, // no store needed for this test
		Mailer:      nil,
		VerifyTTL:   30 * time.Minute,
		RateLimiter: security.NewRateLimiter(1, 100, time.Hour),
		BaseURL:     "http://localhost:5173",
	}
	handlers.Mount(r, deps)

	// First request should pass
	w := httptest.NewRecorder()
	req, _ := http.NewRequest("POST", "/auth/verification/start", bytes.NewBufferString(`{"email":"a@example.com"}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)
	if w.Code != 200 {
		t.Fatalf("expected 200, got %d", w.Code)
	}
	// Second within window should 429
	w2 := httptest.NewRecorder()
	req2, _ := http.NewRequest("POST", "/auth/verification/start", bytes.NewBufferString(`{"email":"a@example.com"}`))
	req2.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w2, req2)
	if w2.Code != 429 {
		t.Fatalf("expected 429, got %d", w2.Code)
	}
}
