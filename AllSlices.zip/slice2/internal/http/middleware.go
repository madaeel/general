
package http

import (
	stdhttp "net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/rs/zerolog/log"
)

// RequestIDMiddleware assigns a unique request ID to each request
func RequestIDMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		id := uuid.New().String()
		c.Set("request_id", id)
		c.Writer.Header().Set("X-Request-ID", id)
		c.Next()
	}
}

// LoggerMiddleware logs each request with structured fields including request ID
func LoggerMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		path := c.Request.URL.Path
		raw := c.Request.URL.RawQuery

		c.Next()

		duration := time.Since(start)
		status := c.Writer.Status()
		reqIDVal, _ := c.Get("request_id")
		reqID, _ := reqIDVal.(string)

		logger := log.With().
			Str("request_id", reqID).
			Str("method", c.Request.Method).
			Str("path", path).
			Int("status", status).
			Dur("duration", duration).
			Logger()

		if raw != "" {
			logger = logger.With().Str("query", raw).Logger()
		}

		if status >= stdhttp.StatusInternalServerError {
			logger.Error().Msg("server error")
		} else if status >= stdhttp.StatusBadRequest {
			logger.Warn().Msg("client error")
		} else {
			logger.Info().Msg("request handled")
		}
	}
}

// RecoveryMiddleware recovers from panics and returns enumeration-safe error
func RecoveryMiddleware() gin.HandlerFunc {
	return gin.CustomRecovery(func(c *gin.Context, recovered interface{}) {
		log.Error().Interface("panic", recovered).Msg("panic recovered")
		c.AbortWithStatusJSON(stdhttp.StatusInternalServerError, gin.H{
			"error": "internal server error",
		})
	})
}
