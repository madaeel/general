
package http

import (
	stdhttp "net/http"

	"github.com/gin-gonic/gin"
	"vespucci/internal/config"
	"vespucci/internal/http/handlers"
)

func NewRouter(cfg *config.Config) *gin.Engine {
	r := gin.New()

	// Middlewares
	r.Use(RequestIDMiddleware())
	r.Use(LoggerMiddleware())
	r.Use(RecoveryMiddleware())

	// Health endpoint
	r.GET("/health", func(c *gin.Context) {
		c.JSON(stdhttp.StatusOK, gin.H{"ok": true})
	})

	return r
}

// NewRouterWithDeps mounts auth routes using provided dependencies.
func NewRouterWithDeps(cfg *config.Config, deps handlers.Deps) *gin.Engine {
	r := NewRouter(cfg)
	handlers.Mount(r, deps)
	handlers.MountVerificationComplete(r, deps)
	handlers.MountRegister(r, deps)
	return r
}
