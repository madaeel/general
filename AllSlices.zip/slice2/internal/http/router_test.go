
package http

import (
	"encoding/json"
	stdhttp "net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"vespucci/internal/config")

func TestHealthEndpoint(t *testing.T) {
	cfg := config.Load()
	router := NewRouter(cfg)

	tests := []struct {
		name           string
		path           string
		expectedCode   int
		expectedResult map[string]bool
	}{
		{
			name:           "health ok",
			path:           "/health",
			expectedCode:   stdhttp.StatusOK,
			expectedResult: map[string]bool{"ok": true},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req, _ := stdhttp.NewRequest("GET", tt.path, nil)
			w := httptest.NewRecorder()
			router.ServeHTTP(w, req)

			if w.Code != tt.expectedCode {
				t.Errorf("expected status %d, got %d", tt.expectedCode, w.Code)
			}

			ct := w.Header().Get("Content-Type")
			if !strings.HasPrefix(ct, "application/json") {
				t.Fatalf("expected Content-Type application/json, got %q", ct)
			}

			var resp map[string]bool
			if err := json.Unmarshal(w.Body.Bytes(), &resp); err != nil {
				t.Fatalf("failed to unmarshal response: %v", err)
			}
			if resp["ok"] != tt.expectedResult["ok"] {
				t.Errorf("expected body %v, got %v", tt.expectedResult, resp)
			}
		})
	}
}
