
package mailer

import "context"

type Mailer interface {
	SendVerificationEmail(ctx context.Context, to, link string) error
}

type noop struct{}

func NewNoop() Mailer { return &noop{} }

func (n *noop) SendVerificationEmail(ctx context.Context, to, link string) error {
	// Intentionally no-op for dev/tests
	return nil
}
