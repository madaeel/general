
package mailer

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
)

type Postmark struct {
	apiKey   string
	from     string
	template string
}

func NewPostmark(apiKey, from, template string) *Postmark {
	return &Postmark{apiKey: apiKey, from: from, template: template}
}

func (p *Postmark) SendVerificationEmail(ctx context.Context, to, link string) error {
	if p.apiKey == "" || p.template == "" {
		return nil
	}
	payload := map[string]any{
		"From":       p.from,
		"To":         to,
		"TemplateId": p.template,
		"TemplateModel": map[string]string{
			"verification_link": link,
		},
	}
	b, _ := json.Marshal(payload)
	req, _ := http.NewRequestWithContext(ctx, "POST", "https://api.postmarkapp.com/email/withTemplate", bytes.NewReader(b))
	req.Header.Set("X-Postmark-Server-Token", p.apiKey)
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	// swallow non-2xx for enumeration safety; log at higher layer in future
	return nil
}
