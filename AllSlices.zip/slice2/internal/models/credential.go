
package models

import (
	"time"

	"github.com/google/uuid"
)

type Credential struct {
	UserID       uuid.UUID `gorm:"type:uuid;primaryKey"`
	PasswordHash string    `gorm:"type:text;not null"`
	PasswordAlgo string    `gorm:"type:text;not null"` // 'argon2id'
	CreatedAt    time.Time `gorm:"type:timestamptz;not null;default:now()"`
	UpdatedAt    time.Time `gorm:"type:timestamptz;not null;default:now()"`
}
