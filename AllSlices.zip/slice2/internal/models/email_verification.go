
package models

import (
	"time"

	"github.com/google/uuid"
)

type EmailVerification struct {
	ID        uuid.UUID `gorm:"type:uuid;default:gen_random_uuid();primaryKey"`
	Email     string    `gorm:"type:citext;not null;index"`
	Purpose   string    `gorm:"type:text;not null"` // 'register'
	TokenHash []byte    `gorm:"type:bytea;not null;uniqueIndex"`
	ExpiresAt time.Time `gorm:"type:timestamptz;not null;index"`
	UsedAt    *time.Time
	CreatedAt time.Time `gorm:"type:timestamptz;not null;default:now()"`
}
