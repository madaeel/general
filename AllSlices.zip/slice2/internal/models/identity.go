
package models

import (
	"time"

	"github.com/google/uuid"
)

type Provider string

const (
	ProviderGoogle   Provider = "google"
	ProviderFacebook Provider = "facebook"
)

type Identity struct {
	ID        uuid.UUID `gorm:"type:uuid;default:gen_random_uuid();primaryKey"`
	UserID    uuid.UUID `gorm:"type:uuid;not null;index"`
	Provider  Provider  `gorm:"type:text;not null;check:provider IN ('google','facebook');uniqueIndex:uidx_identity_provider_subject"`
	Subject   string    `gorm:"type:text;not null;uniqueIndex:uidx_identity_provider_subject"`
	Email     *string   `gorm:"type:citext"`
	DisplayName *string `gorm:"type:text"`
	AvatarURL *string   `gorm:"type:text"`
	CreatedAt time.Time `gorm:"type:timestamptz;not null;default:now()"`
}
