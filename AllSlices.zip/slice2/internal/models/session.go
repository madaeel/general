
package models

import (
	"errors"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Session struct {
	ID         uuid.UUID `gorm:"type:uuid;default:gen_random_uuid();primaryKey"`
	UserID     uuid.UUID `gorm:"type:uuid;not null;index"`
	TokenHash  []byte    `gorm:"type:bytea;not null;uniqueIndex"`
	IssuedAt   time.Time `gorm:"type:timestamptz;not null;default:now()"`
	ExpiresAt  time.Time `gorm:"type:timestamptz;not null;index"`
	IP         *string   `gorm:"type:inet"`
	UserAgent  *string   `gorm:"type:text"`
}

func (s *Session) BeforeCreate(tx *gorm.DB) error {
	if !s.ExpiresAt.After(s.IssuedAt) {
		return errors.New("session expires_at must be after issued_at")
	}
	return nil
}
