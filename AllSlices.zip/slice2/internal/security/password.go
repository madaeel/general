
package security

import (
	"crypto/subtle"
	"encoding/base64"
	"fmt"

	"golang.org/x/crypto/argon2"
)

type Argon2Params struct {
	Time    int
	Memory  int
	Threads uint8
	KeyLen  uint32
}

// Argon2idHash returns an encoded RFC 9106 style string
func Argon2idHash(password []byte, p Argon2Params, salt []byte) (string, error) {
	if len(salt) < 16 {
		return "", fmt.Errorf("salt too short" )
	}
	key := argon2.IDKey(password, salt, uint32(p.Time), uint32(p.Memory), p.Threads, p.KeyLen)
	encSalt := base64.RawStdEncoding.EncodeToString(salt)
	encKey := base64.RawStdEncoding.EncodeToString(key)
	return fmt.Sprintf("$argon2id$v=19$t=%d,m=%d,p=%d$%s$%s", p.Time, p.Memory, p.Threads, encSalt, encKey), nil
}

// ValidatePassword compares a password to an encoded hash
func ValidatePassword(password []byte, encoded string) error {
	var ver int
	var t, m, p int
	var b64Salt, b64Key string
	if _, err := fmt.Sscanf(encoded, "$argon2id$v=%d$t=%d,m=%d,p=%d$%s$%s", &ver, &t, &m, &p, &b64Salt, &b64Key); err != nil {
		return fmt.Errorf("invalid hash")
	}
	salt, err := base64.RawStdEncoding.DecodeString(b64Salt)
	if err != nil {
		return fmt.Errorf("invalid hash")
	}
	wantKey, err := base64.RawStdEncoding.DecodeString(b64Key)
	if err != nil {
		return fmt.Errorf("invalid hash")
	}
	key := argon2.IDKey(password, salt, uint32(t), uint32(m), uint8(p), uint32(len(wantKey)))
	if subtle.ConstantTimeCompare(key, wantKey) != 1 {
		return fmt.Errorf("invalid password")
	}
	return nil
}
