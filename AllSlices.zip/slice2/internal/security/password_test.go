
package security_test

import (
	"testing"

	"vespucci/internal/security"
)

func TestArgon2HashAndValidate(t *testing.T) {
	params := security.Argon2Params{Time: 1, Memory: 64 * 1024, Threads: 2, KeyLen: 32}
	salt := make([]byte, 16)
	for i := range salt {
		salt[i] = byte(i)
	}
	hash, err := security.Argon2idHash([]byte("P@ssword123"), params, salt)
	if err != nil {
		t.Fatalf("hash error: %v", err)
	}
	if err := security.ValidatePassword([]byte("P@ssword123"), hash); err != nil {
		t.Fatalf("validate failed: %v", err)
	}
	if err := security.ValidatePassword([]byte("wrong"), hash); err == nil {
		t.Fatalf("expected invalid password")
	}
}
