
package security

import (
	"sync"
	"time"
)

type RateLimiter struct {
	mu          sync.Mutex
	emailCounts map[string][]time.Time
	ipCounts    map[string][]time.Time
	maxEmail    int
	maxIP       int
	window      time.Duration
}

func NewRateLimiter(maxEmail, maxIP int, window time.Duration) *RateLimiter {
	return &RateLimiter{
		emailCounts: make(map[string][]time.Time),
		ipCounts:    make(map[string][]time.Time),
		maxEmail:    maxEmail,
		maxIP:       maxIP,
		window:      window,
	}
}

func (r *RateLimiter) Allow(email, ip string, now time.Time) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	since := now.Add(-r.window)
	es := prune(r.emailCounts[email], since)
	is := prune(r.ipCounts[ip], since)
	if len(es) >= r.maxEmail || len(is) >= r.maxIP {
		r.emailCounts[email] = es
		r.ipCounts[ip] = is
		return false
	}
	es = append(es, now)
	is = append(is, now)
	r.emailCounts[email] = es
	r.ipCounts[ip] = is
	return true
}

func prune(times []time.Time, since time.Time) []time.Time {
	if len(times) == 0 {
		return times
	}
	i := 0
	for _, t := range times {
		if t.After(since) {
			times[i] = t
			i++
		}
	}
	return times[:i]
}
