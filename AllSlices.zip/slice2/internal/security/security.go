
package security

// placeholder for future shared helpers
