
package security

import (
	"crypto/rand"
	"crypto/sha256"
)

func GenerateToken(n int) ([]byte, error) {
	b := make([]byte, n)
	_, err := rand.Read(b)
	return b, err
}

func HashTokenSHA256(b []byte) []byte {
	h := sha256.Sum256(b)
	return h[:]
}
