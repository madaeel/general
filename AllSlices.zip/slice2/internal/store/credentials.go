
package store

import (
	"context"

	"github.com/google/uuid"
	"gorm.io/gorm/clause"
	"vespucci/internal/models"
)

func (s *PGStore) UpsertUserCredentialArgon2id(ctx context.Context, userID uuid.UUID, hash string) error {
	cred := models.Credential{
		UserID:       userID,
		PasswordHash: hash,
		PasswordAlgo: "argon2id",
	}
	err := s.db.WithContext(ctx).Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "user_id"}},
		DoUpdates: clause.AssignmentColumns([]string{"password_hash", "password_algo", "updated_at"}),
	}).Create(&cred).Error
	return mapDBError(err)
}
