
package store

import (
	"context"
	"time"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"vespucci/internal/models"
)

func (s *PGStore) CreateEmailVerification(ctx context.Context, v *models.EmailVerification) error {
	if err := s.db.WithContext(ctx).Create(v).Error; err != nil {
		return mapDBError(err)
	}
	return nil
}

func (s *PGStore) ConsumeEmailVerification(ctx context.Context, tokenHash []byte, now time.Time) (string, error) {
	var v models.EmailVerification
	tx := s.db.WithContext(ctx).Begin()
	if err := tx.
		Clauses(clause.Locking{Strength: "UPDATE"}).
		First(&v, "token_hash = ?", tokenHash).Error; err != nil {
		tx.Rollback()
		return "", ErrNotFound
	}
	if v.UsedAt != nil || v.ExpiresAt.Before(now) {
		tx.Rollback()
		return "", ErrInvalid
	}
	used := now
	if err := tx.Model(&v).Update("used_at", &used).Error; err != nil {
		tx.Rollback()
		return "", ErrOperationFailed
	}
	if err := tx.Commit().Error; err != nil {
		return "", ErrOperationFailed
	}
	return v.Email, nil
}
