
package store

import (
	"context"
	"database/sql"
	"strings"
	"time"

	"github.com/google/uuid"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"vespucci/internal/models"
)

type PGStore struct {
	db *gorm.DB
	pool DBPool
}

type DBPool struct {
	MaxOpen     int
	MaxIdle     int
	MaxLifetime string // duration string
}

func NewPostgresStore(url string, pool DBPool) (*PGStore, error) {
	dial := postgres.Open(url)
	db, err := gorm.Open(dial, &gorm.Config{})
	if err != nil {
		return nil, err
	}
	// Configure connection pool if possible
	sqlDB, err := db.DB()
	if err == nil {
		if pool.MaxOpen > 0 {
			sqlDB.SetMaxOpenConns(pool.MaxOpen)
		}
		if pool.MaxIdle > 0 {
			sqlDB.SetMaxIdleConns(pool.MaxIdle)
		}
		if pool.MaxLifetime != "" {
			if d, err := time.ParseDuration(pool.MaxLifetime); err == nil {
				sqlDB.SetConnMaxLifetime(d)
			}
		}
	}
	return &PGStore{db: db, pool: pool}, nil
}

func (s *PGStore) Close() error {
	sqlDB, err := s.db.DB()
	if err != nil {
		return err
	}
	return sqlDB.Close()
}

func mapDBError(err error) error {
	if err == nil {
		return nil
	}
	if err == gorm.ErrRecordNotFound {
		return ErrNotFound
	}
	if err == sql.ErrNoRows {
		return ErrNotFound
	}
	// crude unique violation fallback by message
	if strings.Contains(strings.ToLower(err.Error()), "duplicate") {
		return ErrConflict
	}
	return err
}

// Users
func (s *PGStore) CreateUser(ctx context.Context, u *models.User) error {
	return mapDBError(s.db.WithContext(ctx).Create(u).Error)
}

func (s *PGStore) FindUserByEmailNormalized(ctx context.Context, emailNorm string) (*models.User, error) {
	var u models.User
	if err := s.db.WithContext(ctx).Where("email_normalized = ?", strings.ToLower(emailNorm)).First(&u).Error; err != nil {
		return nil, mapDBError(err)
	}
	return &u, nil
}

// Audit
func (s *PGStore) CreateAuditEvent(ctx context.Context, ev *models.AuditEvent) error {
	return mapDBError(s.db.WithContext(ctx).Create(ev).Error)
}
