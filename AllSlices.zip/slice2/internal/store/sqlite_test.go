
package store_test

import (
	"testing"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"vespucci/internal/models"
)

func TestAutoMigrateModelsSQLite(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:?cache=shared"), &gorm.Config{})
	if err != nil {
		t.Fatal(err)
	}
	if err := db.AutoMigrate(
		&models.User{},
		&models.Identity{},
		&models.Session{},
		&models.AuditEvent{},
		&models.EmailVerification{},
		&models.Credential{},
	); err != nil {
		t.Fatalf("automigrate failed: %v", err)
	}
}
