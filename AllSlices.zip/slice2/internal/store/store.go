
package store

import (
	"context"
	"time"

	"github.com/google/uuid"
	"vespucci/internal/models"
)

type Store interface {
	Close() error

	// Users
	CreateUser(ctx context.Context, u *models.User) error
	FindUserByEmailNormalized(ctx context.Context, emailNorm string) (*models.User, error)

	// Audit
	CreateAuditEvent(ctx context.Context, ev *models.AuditEvent) error

	// Email verification
	CreateEmailVerification(ctx context.Context, v *models.EmailVerification) error
	ConsumeEmailVerification(ctx context.Context, tokenHash []byte, now time.Time) (string, error) // returns email

	// Credentials
	UpsertUserCredentialArgon2id(ctx context.Context, userID uuid.UUID, hash string) error
}
