
DROP TABLE IF EXISTS user_credentials;
DROP TABLE IF EXISTS email_verifications;
