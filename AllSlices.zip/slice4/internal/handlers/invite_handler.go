package handlers

import (
    "net/http"

    "vespucci/internal/services"

    "github.com/gin-gonic/gin"
    "github.com/google/uuid"
)

type InviteHandler struct {
    Service *services.InviteService
}

type CreateInviteRequest struct {
    OrganizationID uuid.UUID `json:"organizationId" binding:"required"`
    Email          string    `json:"email" binding:"required,email"`
    Role           string    `json:"role" binding:"required,oneof=owner admin agent viewer"`
}

func (h *InviteHandler) CreateInvite(c *gin.Context) {
    var req CreateInviteRequest
    if err := c.ShouldBindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid_request", "message": err.Error()})
        return
    }
    invite, _, err := h.Service.CreateInvite(req.OrganizationID, req.Email, req.Role)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "server_error", "message": err.Error()})
        return
    }
    c.JSON(http.StatusCreated, gin.H{
        "id":            invite.ID,
        "organizationId": invite.OrganizationID,
        "email":         invite.Email,
        "role":          invite.Role,
        "status":        invite.Status,
        "createdAt":     invite.CreatedAt,
        "expiresAt":     invite.ExpiresAt,
    })
    // TODO: deliver token securely via email, not in API response
}

type AcceptInviteRequest struct {
    Token string `json:"token" binding:"required"`
}

func (h *InviteHandler) AcceptInvite(c *gin.Context) {
    var req AcceptInviteRequest
    if err := c.ShouldBindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid_request", "message": err.Error()})
        return
    }
    invite, err := h.Service.AcceptInvite(req.Token)
    if err != nil {
        if err.Error() == "invalid_invite" || err.Error() == "expired_invite" {
            c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "message": "invite not valid"})
            return
        }
        c.JSON(http.StatusInternalServerError, gin.H{"error": "server_error", "message": err.Error()})
        return
    }
    c.JSON(http.StatusOK, gin.H{"ok": true, "inviteId": invite.ID})
}
