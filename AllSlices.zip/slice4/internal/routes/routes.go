package routes

import (
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"

    "vespucci/internal/handlers"
    "vespucci/internal/services"
)

func RegisterRoutes(r *gin.Engine, db *gorm.DB) {
    authHandler := &handlers.AuthHandler{Service: &services.AuthService{DB: db}}
    sessionHandler := &handlers.SessionHandler{Service: &services.SessionService{DB: db}}
    inviteHandler := &handlers.InviteHandler{Service: &services.InviteService{DB: db}}

    api := r.Group("/auth")
    {
        api.POST("/register", authHandler.Register)
        api.POST("/login", authHandler.Login)
        api.POST("/magic-link-request", authHandler.MagicLinkRequest)
        api.POST("/magic-link-consume", authHandler.MagicLinkConsume)
        api.POST("/password/forgot", authHandler.ForgotPassword)
        api.POST("/password/reset", authHandler.ResetPassword)
        api.POST("/logout", authHandler.Logout)
    }

    invites := r.Group("/invites")
    {
        invites.POST("", inviteHandler.CreateInvite)
        invites.POST("/accept", inviteHandler.AcceptInvite)
    }

    sessions := r.Group("/sessions")
    {
        sessions.GET("", sessionHandler.ListSessions)
        sessions.POST("/:id/revoke", sessionHandler.RevokeSession)
    }
}
