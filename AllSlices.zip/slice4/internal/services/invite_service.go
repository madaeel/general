package services

import (
    "crypto/sha256"
    "encoding/hex"
    "errors"
    "time"

    "vespucci/internal/models"

    "github.com/google/uuid"
    "gorm.io/gorm"
)

type InviteService struct {
    DB *gorm.DB
}

func (s *InviteService) CreateInvite(orgID uuid.UUID, email string, role string) (*models.Invite, string, error) {
    plainToken := uuid.NewString()
    hash := sha256.Sum256([]byte(plainToken))
    tokenHash := hex.EncodeToString(hash[:])

    invite := &models.Invite{
        OrganizationID: orgID,
        Email:          email,
        Role:           role,
        TokenHash:      tokenHash,
        ExpiresAt:      time.Now().Add(14 * 24 * time.Hour),
    }
    if err := s.DB.Create(invite).Error; err != nil {
        return nil, "", err
    }
    return invite, plainToken, nil
}

func (s *InviteService) AcceptInvite(token string) (*models.Invite, error) {
    hash := sha256.Sum256([]byte(token))
    tokenHash := hex.EncodeToString(hash[:])

    var invite models.Invite
    if err := s.DB.Where("token_hash = ? AND status = ?", tokenHash, "pending").First(&invite).Error; err != nil {
        if errors.Is(err, gorm.ErrRecordNotFound) {
            return nil, errors.New("invalid_invite")
        }
        return nil, err
    }
    if time.Now().After(invite.ExpiresAt) {
        return nil, errors.New("expired_invite")
    }
    now := time.Now()
    invite.Status = "accepted"
    invite.AcceptedAt = &now
    if err := s.DB.Save(&invite).Error; err != nil {
        return nil, err
    }

    // TODO: obtain actual userID from authenticated context or registration flow
    // Placeholder membership activation example:
    // membership := models.Membership{
    //     UserID:        someUserID,
    //     OrganizationID: invite.OrganizationID,
    //     Role:          invite.Role,
    //     Status:        "active",
    //     JoinedAt:      &now,
    // }
    // _ = s.DB.Create(&membership)

    return &invite, nil
}
