Slice 5 - Social Providers

Prereqs
- Go 1.22

Env example
- SESSION_COOKIE_NAME=vespucci_session
- SESSION_DAYS=7
- SOCIAL_PROVIDERS_ENABLED=google,facebook
- GOOGLE_CLIENT_ID=your-google-client-id
- GOOGLE_CLIENT_SECRET=your-google-client-secret
- GOOGLE_REDIRECT_URI=https://yourapp.example.com/oauth/google/callback
- FACEBOOK_CLIENT_ID=your-facebook-app-id
- FACEBOOK_CLIENT_SECRET=your-facebook-app-secret
- FACEBOOK_REDIRECT_URI=https://yourapp.example.com/oauth/facebook/callback

Commands
- go test ./...
- go run ./cmd/api

Notes
- Protected endpoints will be wrapped with SessionCookieAuth middleware in Slice 3.
- CSRF header enforcement and JWKS verification will be added in Slice 6.
