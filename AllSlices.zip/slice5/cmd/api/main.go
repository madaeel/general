package main

import (
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/vespucci/auth/internal/config"
	apphttp "github.com/vespucci/auth/internal/http"
)

func main() {
	cfg := config.LoadFromEnv()
	if err := cfg.Validate(); err != nil {
		log.Fatal("configuration error: ", err)
	}
	r := gin.Default()
	apphttp.RegisterRoutes(r, cfg)

	addr := os.Getenv("ADDR")
	if addr == "" {
		addr = ":8080"
	}
	if err := r.Run(addr); err != nil {
		log.Fatal(err)
	}
}
