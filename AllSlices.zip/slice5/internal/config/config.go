package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	SessionCookieName    string
	SessionDays          int
	SocialProviders      []string
	GoogleClientID       string
	GoogleClientSecret   string
	GoogleRedirectURI    string
	FacebookClientID     string
	FacebookClientSecret string
	FacebookRedirectURI  string
}

func LoadFromEnv() Config {
	providers := strings.Split(os.Getenv("SOCIAL_PROVIDERS_ENABLED"), ",")
	trim := func(in []string) []string {
		out := []string{}
		for _, p := range in {
			p = strings.TrimSpace(strings.ToLower(p))
			if p != "" {
				out = append(out, p)
			}
		}
		return out
	}
	return Config{
		SessionCookieName:    envDefault("SESSION_COOKIE_NAME", "vespucci_session"),
		SessionDays:          envIntDefault("SESSION_DAYS", 7),
		SocialProviders:      trim(providers),
		GoogleClientID:       os.Getenv("GOOGLE_CLIENT_ID"),
		GoogleClientSecret:   os.Getenv("GOOGLE_CLIENT_SECRET"),
		GoogleRedirectURI:    os.Getenv("GOOGLE_REDIRECT_URI"),
		FacebookClientID:     os.Getenv("FACEBOOK_CLIENT_ID"),
		FacebookClientSecret: os.Getenv("FACEBOOK_CLIENT_SECRET"),
		FacebookRedirectURI:  os.Getenv("FACEBOOK_REDIRECT_URI"),
	}
}

func SessionTTL(cfg Config) time.Duration {
	d := cfg.SessionDays
	if d <= 0 {
		d = 7
	}
	return time.Duration(d) * 24 * time.Hour
}

func envDefault(key, def string) string {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	return v
}

func envIntDefault(key string, def int) int {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	if n, err := strconv.Atoi(v); err == nil && n > 0 {
		return n
	}
	return def
}

// Validate ensures that if a provider is enabled, required settings exist.
func (c Config) Validate() error {
	set := map[string]bool{}
	for _, p := range c.SocialProviders {
		if set[p] {
			return fmt.Errorf("duplicate provider in SOCIAL_PROVIDERS_ENABLED: %s", p)
		}
		set[p] = true
		switch p {
		case "google":
			if c.GoogleClientID == "" || c.GoogleRedirectURI == "" {
				return fmt.Errorf("google enabled but GOOGLE_CLIENT_ID or GOOGLE_REDIRECT_URI is missing")
			}
		case "facebook":
			if c.FacebookClientID == "" || c.FacebookRedirectURI == "" {
				return fmt.Errorf("facebook enabled but FACEBOOK_CLIENT_ID or FACEBOOK_REDIRECT_URI is missing")
			}
		default:
			return fmt.Errorf("unsupported provider in SOCIAL_PROVIDERS_ENABLED: %s", p)
		}
	}
	return nil
}
