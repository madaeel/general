package handlers

import (
	"errors")
import (
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/vespucci/auth/internal/config"
	"github.com/vespucci/auth/internal/providers"
)

type SocialHandler struct {
	cfg config.Config
	p   providers.Registry
}

func NewSocialHandler(cfg config.Config) *SocialHandler {
	return &SocialHandler{
		cfg: cfg,
		p:   providers.NewRegistry(cfg),
	}
}

// GET /auth/providers
func (h *SocialHandler) ListProviders(c *gin.Context) {
	out := struct {
		Providers []string `json:"providers"`
	}{Providers: h.cfg.SocialProviders}
	c.JSON(http.StatusOK, out)
}

// GET /auth/{provider}/authorize -> 302 Location
func (h *SocialHandler) Authorize(c *gin.Context) {
	provider := strings.ToLower(c.Param("provider"))
	pr, ok := h.p.Get(provider)
	if !ok {
		c.JSON(http.StatusBadRequest, errorObj("invalid_request", "Invalid request"))
		return
	}
	redirect := c.Query("redirect")
	state, verifier, err := pr.BeginAuth(c, redirect)
	if err != nil {
		c.JSON(http.StatusBadRequest, errorObj("invalid_request", "Unable to initiate provider flow"))
		return
	}
	authURL := pr.AuthURL(state, verifier)
	c.Header("Location", authURL)
	c.Status(http.StatusFound)
}

// POST /auth/{provider}/callback
func (h *SocialHandler) Callback(c *gin.Context) {
	provider := strings.ToLower(c.Param("provider"))
	pr, ok := h.p.Get(provider)
	if !ok {
		c.JSON(http.StatusBadRequest, errorObj("invalid_request", "Invalid request"))
		return
	}
	var body struct {
		Code  string `json:"code" binding:"required"`
		State string `json:"state" binding:"required"`
		Link  bool   `json:"link"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		c.JSON(http.StatusBadRequest, errorObj("invalid_request", "Invalid payload"))
		return
	}

	claims, err := pr.ExchangeAndVerify(c, body.Code, body.State)
	if err != nil {
		c.JSON(http.StatusBadRequest, errorObj("invalid_request", "Provider verification failed"))
		return
	}

	_ = claims

	c.JSON(http.StatusOK, gin.H{"ok": true})
}

// POST /auth/{provider}/link - authenticated in full implementation
func (h *SocialHandler) Link(c *gin.Context) {
	provider := strings.ToLower(c.Param("provider"))
	pr, ok := h.p.Get(provider)
	if !ok {
		c.JSON(http.StatusBadRequest, errorObj("invalid_request", "Invalid request"))
		return
	}
	var body struct {
		Code  string `json:"code" binding:"required"`
		State string `json:"state" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		c.JSON(http.StatusBadRequest, errorObj("invalid_request", "Invalid payload"))
		return
	}
	claims, err := pr.ExchangeAndVerify(c, body.Code, body.State)
	if err != nil {
		c.JSON(http.StatusBadRequest, errorObj("invalid_request", "Provider verification failed"))
		return
	}
	puid := claims.ProviderUserID

	c.JSON(http.StatusOK, gin.H{
		"id":             uuid.NewString(),
		"userId":         uuid.NewString(),
		"provider":       provider,
		"providerUserId": puid,
		"emailAtLogin":   nil,
		"claims":         map[string]any{},
		"linkedAt":       time.Now().UTC().Format(time.RFC3339),
	})
}

// POST /auth/{provider}/unlink - authenticated in full implementation
func (h *SocialHandler) Unlink(c *gin.Context) {
	c.Status(http.StatusNoContent)
}

// GET /me/social-identities - authenticated in full implementation
func (h *SocialHandler) ListLinked(c *gin.Context) {
	c.JSON(http.StatusOK, []any{})
}

func errorObj(code, msg string) gin.H {
	return gin.H{
		"error":         code,
		"message":       msg,
		"correlationId": uuid.NewString(),
	}
}
