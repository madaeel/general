package handlers_test

import (
	"encoding/json"
	"net/http"
	"testing"

	"github.com/vespucci/auth/internal/testhelpers"
)

func TestListProviders(t *testing.T) {
	ts := testhelpers.NewServer(t)
	w := ts.Req("GET", "/auth/providers", "")
	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}
	var resp struct { Providers []string `json:"providers"` }
	_ = json.Unmarshal(w.Body.Bytes(), &resp)
	if len(resp.Providers) == 0 {
		t.Fatalf("expected providers list")
	}
}

func TestAuthorizeRedirect(t *testing.T) {
	ts := testhelpers.NewServer(t)
	w := ts.Req("GET", "/auth/google/authorize", "")
	if w.Code != http.StatusFound {
		t.Fatalf("expected 302, got %d body=%s", w.Code, w.Body.String())
	}
	loc := w.Header().Get("Location")
	if loc == "" {
		t.Fatalf("expected Location header")
	}
}

func TestCallbackHappyPath(t *testing.T) {
	ts := testhelpers.NewServer(t)
	body := `{"code":"abc","state":"xyz"}`
	w := ts.Req("POST", "/auth/google/callback", body)
	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d body=%s", w.Code, w.Body.String())
	}
}

func TestUnsupportedProviderNeutralError(t *testing.T) {
	ts := testhelpers.NewServer(t)
	w := ts.Req("GET", "/auth/unknown/authorize", "")
	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", w.Code)
	}
	var resp map[string]any
	_ = json.Unmarshal(w.Body.Bytes(), &resp)
	if resp["error"] != "invalid_request" {
		t.Fatalf("expected error=invalid_request, got %v", resp["error"])
	}
}
