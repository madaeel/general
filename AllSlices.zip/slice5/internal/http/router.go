package http

import (
	"github.com/gin-gonic/gin"
	"github.com/vespucci/auth/internal/config"
	"github.com/vespucci/auth/internal/http/handlers"
)

func RegisterRoutes(r *gin.Engine, cfg config.Config) {
	h := handlers.NewSocialHandler(cfg)

	// Social
	r.GET("/auth/providers", h.ListProviders)
	r.GET("/auth/:provider/authorize", h.Authorize)
	r.POST("/auth/:provider/callback", h.Callback)
	// TODO: add SessionCookieAuth middleware when session stack is wired (Slice 3)
	r.POST("/auth/:provider/link", h.Link)
	r.POST("/auth/:provider/unlink", h.Unlink)

	// Me
	// TODO: add SessionCookieAuth middleware when session stack is wired (Slice 3)
	r.GET("/me/social-identities", h.ListLinked)
}
