-- Idempotent creation of social_identities table for Slice 5
DO $$
BEGIN
	IF NOT EXISTS (
		SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'social_identities'
	) THEN
		CREATE TABLE public.social_identities (
			id uuid PRIMARY KEY,
			user_id uuid NOT NULL,
			provider text NOT NULL,
			provider_user_id text NOT NULL,
			email_at_login text NULL,
			claims_json jsonb NOT NULL DEFAULT '{}'::jsonb,
			linked_at timestamptz NOT NULL DEFAULT now(),
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now(),
			deleted_at timestamptz NULL
		);
		CREATE INDEX IF NOT EXISTS idx_social_identities_user ON public.social_identities (user_id);
		CREATE INDEX IF NOT EXISTS idx_social_identities_provider ON public.social_identities (provider);
		CREATE INDEX IF NOT EXISTS idx_social_identities_provider_user ON public.social_identities (provider_user_id);
	END IF;
END$$;
