-- Safe rollback: only drop if table exists and is empty
DO $$
BEGIN
	IF EXISTS (
		SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'social_identities'
	) THEN
		IF NOT EXISTS (SELECT 1 FROM public.social_identities LIMIT 1) THEN
			DROP TABLE public.social_identities;
		END IF;
	END IF;
END$$;
