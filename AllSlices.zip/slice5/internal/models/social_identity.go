package models

import (
	"time"

	"gorm.io/gorm"
)

type SocialIdentity struct {
	ID             string         `gorm:"type:uuid;primaryKey"`
	UserID         string         `gorm:"type:uuid;index"`
	Provider       string         `gorm:"type:text;index"`
	ProviderUserID string         `gorm:"type:text;index"`
	EmailAtLogin   *string        `gorm:"type:text"`
	ClaimsJSON     []byte         `gorm:"type:jsonb"`
	LinkedAt       time.Time      `gorm:"not null"`
	CreatedAt      time.Time
	UpdatedAt      time.Time
	DeletedAt      gorm.DeletedAt `gorm:"index"`
}

func (SocialIdentity) TableName() string { return "social_identities" }
