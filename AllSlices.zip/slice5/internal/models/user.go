package models

import "time"

type User struct {
	ID              string     `gorm:"type:uuid;primaryKey"`
	Email           string     `gorm:"uniqueIndex"`
	GivenName       string
	FamilyName      string
	HasPassword     bool
	EmailVerifiedAt *time.Time
	CreatedAt       time.Time
	UpdatedAt       time.Time
}
