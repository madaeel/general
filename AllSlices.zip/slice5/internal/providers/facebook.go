package providers

import (
	"errors"
	"net/url"

	"github.com/gin-gonic/gin"
	"github.com/vespucci/auth/internal/config"
)

type facebookProvider struct{ cfg config.Config }

func NewFacebook(cfg config.Config) Provider { return &facebookProvider{cfg: cfg} }
func (f *facebookProvider) Name() string     { return "facebook" }

func (f *facebookProvider) BeginAuth(c *gin.Context, redirect string) (string, string, error) {
	if f.cfg.FacebookClientID == "" || f.cfg.FacebookRedirectURI == "" {
		return "", "", notConfigured(f.Name())
	}
	state := randomB64(24)
	return state, "", nil
}

func (f *facebookProvider) AuthURL(state, _ string) string {
	v := url.Values{}
	v.Set("client_id", f.cfg.FacebookClientID)
	v.Set("redirect_uri", f.cfg.FacebookRedirectURI)
	v.Set("response_type", "code")
	v.Set("scope", "email,public_profile")
	v.Set("state", state)
	return "https://www.facebook.com/v18.0/dialog/oauth?" + v.Encode()
}

func (f *facebookProvider) ExchangeAndVerify(c *gin.Context, code, state string) (Claims, error) {
	if code == "" || state == "" {
		return Claims{}, errors.New("invalid code/state")
	}
	return Claims{
		Provider:       f.Name(),
		ProviderUserID: "facebook-test-user",
		Email:          "user@example.com",
		EmailVerified:  true,
		GivenName:      "Test",
		FamilyName:     "User",
		Raw:            map[string]any{"mock": true},
	}, nil
}
