package providers

import (
	"crypto/rand"
	"encoding/base64"
	"errors"
	"net/url"

	"github.com/gin-gonic/gin"
	"github.com/vespucci/auth/internal/config"
)

type googleProvider struct {
	cfg config.Config
}

func NewGoogle(cfg config.Config) Provider {
	return &googleProvider{cfg: cfg}
}

func (g *googleProvider) Name() string { return "google" }

func (g *googleProvider) BeginAuth(c *gin.Context, redirect string) (string, string, error) {
	if g.cfg.GoogleClientID == "" || g.cfg.GoogleRedirectURI == "" {
		return "", "", notConfigured(g.Name())
	}
	state := randomB64(24)
	verifier := randomB64(32)
	return state, verifier, nil
}

func (g *googleProvider) AuthURL(state, verifier string) string {
	v := url.Values{}
	v.Set("client_id", g.cfg.GoogleClientID)
	v.Set("redirect_uri", g.cfg.GoogleRedirectURI)
	v.Set("response_type", "code")
	v.Set("scope", "openid email profile")
	v.Set("state", state)
	return "https://accounts.google.com/o/oauth2/v2/auth?" + v.Encode()
}

func (g *googleProvider) ExchangeAndVerify(c *gin.Context, code, state string) (Claims, error) {
	if code == "" || state == "" {
		return Claims{}, errors.New("invalid code/state")
	}
	return Claims{
		Provider:       g.Name(),
		ProviderUserID: "google-test-user",
		Email:          "user@example.com",
		EmailVerified:  true,
		GivenName:      "Test",
		FamilyName:     "User",
		Raw:            map[string]any{"mock": true},
	}, nil
}

func randomB64(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return base64.RawURLEncoding.EncodeToString(b)
}
