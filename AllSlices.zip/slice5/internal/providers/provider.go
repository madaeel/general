package providers

import (
	"context"
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/vespucci/auth/internal/config"
)

type Claims struct {
	Provider       string
	ProviderUserID string
	Email          string
	EmailVerified  bool
	GivenName      string
	FamilyName     string
	Raw            map[string]any
}

type Provider interface {
	Name() string
	BeginAuth(c *gin.Context, redirect string) (state string, codeVerifier string, err error)
	AuthURL(state, codeVerifier string) string
	ExchangeAndVerify(c *gin.Context, code, state string) (Claims, error)
}

type Registry interface {
	Get(name string) (Provider, bool)
}

type registry struct {
	set map[string]Provider
}

func NewRegistry(cfg config.Config) Registry {
	r := &registry{set: map[string]Provider{}}
	for _, p := range cfg.SocialProviders {
		switch p {
		case "google":
			r.set[p] = NewGoogle(cfg)
		case "facebook":
			r.set[p] = NewFacebook(cfg)
		default:
			// ignore unknowns
		}
	}
	return r
}

func (r *registry) Get(name string) (Provider, bool) {
	p, ok := r.set[name]
	return p, ok
}

func ensureRedirect(base, fallback string) string {
	if base == "" {
		return fallback
	}
	return base
}

func ctx(c *gin.Context) context.Context {
	if c == nil {
		return context.Background()
	}
	return c.Request.Context()
}

func notConfigured(name string) error {
	return fmt.Errorf("%s provider not configured", name)
}
