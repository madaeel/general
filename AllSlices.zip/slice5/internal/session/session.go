package session

import (
	"time"

	"github.com/google/uuid"
)

type Session struct {
	ID        string
	UserID    string
	ExpiresAt time.Time
}

func New(userID string, ttl time.Duration) Session {
	return Session{
		ID:        uuid.NewString(),
		UserID:    userID,
		ExpiresAt: time.Now().Add(ttl),
	}
}
