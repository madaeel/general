package testhelpers

import (
	"net/http/httptest"
	"testing"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/vespucci/auth/internal/config"
	apphttp "github.com/vespucci/auth/internal/http"
)

type TestServer struct {
	T   *testing.T
	R   *gin.Engine
	Cfg config.Config
}

func NewServer(t *testing.T) *TestServer {
	t.Helper()
	gin.SetMode(gin.TestMode)
	cfg := config.Config{
		SessionCookieName:  "vespucci_session",
		SessionDays:        7,
		SocialProviders:    []string{"google", "facebook"},
		GoogleClientID:     "test",
		GoogleRedirectURI:  "https://example.com/google/callback",
		FacebookClientID:   "test",
		FacebookRedirectURI: "https://example.com/facebook/callback",
	}
	r := gin.New()
	apphttp.RegisterRoutes(r, cfg)
	return &TestServer{T: t, R: r, Cfg: cfg}
}

func (ts *TestServer) Req(method, path string, body string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, path, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	ts.R.ServeHTTP(w, req)
	return w
}
