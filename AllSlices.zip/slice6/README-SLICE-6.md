Slice 6, Audit, rate limits, hardening

Contents
- Migrations for audit_log
- Audit service
- Rate limit and CSRF middlewares
- Enumeration safe error helper
- Router wiring example
- Tests and migrate script

Quick start
1. Ensure Go and Postgres available
2. DATABASE_URL=... ./scripts/migrate.sh up
3. go test ./...

Notes
- Update your real server wiring to call buildRouter(db)
- Adjust route keys in ratelimit config if your paths differ
- Plan a 12 month retention mechanism for audit logs
