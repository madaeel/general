package main

import (
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/bkplane/vespucci/internal/middleware/ratelimit"
	"github.com/bkplane/vespucci/internal/middleware/csrf"
	"github.com/bkplane/vespucci/internal/audit"
	"gorm.io/gorm"
)

// buildRouter constructs the Gin engine and wires middlewares introduced in Slice 6.
func buildRouter(db *gorm.DB) *gin.Engine {
	r := gin.New()
	r.Use(gin.Recovery())

	// correlation id per request
	r.Use(func(c *gin.Context) {
		c.Set("correlation_id", uuid.NewString())
		c.Next()
	})

	// Audit service used by middlewares
	auditSvc := &audit.Service{DB: db}
	onBlocked := func(action audit.Action) func(c *gin.Context) {
		return func(c *gin.Context) {
			ip := c.ClientIP()
			ua := c.Request.UserAgent()
			route := c.FullPath()
			method := c.Request.Method
			_ = auditSvc.Write(c.Request.Context(), audit.Entry{
				Action: action,
				IP:     &ip, UserAgent: &ua, Route: &route, Method: &method,
			})
		}
	}

	// Rate limiting for sensitive endpoints
	rl := ratelimit.New(ratelimit.Config{
		DefaultPerMinute: 60,
		Routes: map[string]int{
			"POST:/auth/login":               10,
			"POST:/auth/password/forgot":     5,
			"POST:/auth/password/reset":      5,
			"POST:/auth/magic-link-request":  5,
			"POST:/auth/magic-link-consume":  5,
			"POST:/auth/:provider/callback": 10,
			"POST:/invites":                  10,
			"POST:/invites/accept":           10,
			"POST:*":                         60,
		},
		OnBlocked: onBlocked(audit.ActionRateLimitBlocked),
	})
	r.Use(rl.Middleware())

	// CSRF header enforcement
	r.Use(csrf.Middleware(csrf.Config{
		HeaderName:               "X-CSRF-Token",
		DoubleSubmitCookieName:   "csrf_token",
		RequireDoubleSubmitMatch: false,
		OnBlocked:                onBlocked(audit.ActionCSRFBlocked),
	}))

	// mount routes here...
	return r
}
