-- Slice 6: audit_log table and enum, idempotent
CREATE EXTENSION IF NOT EXISTS pgcrypto;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'audit_action') THEN
    CREATE TYPE audit_action AS ENUM (
      'login_succeeded',
      'login_failed',
      'logout',
      'register_requested',
      'register_completed',
      'password_reset_requested',
      'password_reset_completed',
      'invite_created',
      'invite_accepted',
      'social_linked',
      'social_unlinked',
      'provider_callback_failed',
      'session_revoked',
      'token_consumed',
      'rate_limit_blocked',
      'csrf_blocked'
    );
  END IF;
END$$;

CREATE TABLE IF NOT EXISTS audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  action audit_action NOT NULL,
  actor_user_id UUID NULL,
  organization_id UUID NULL,
  ip INET NULL,
  user_agent TEXT NULL,
  route TEXT NULL,
  method TEXT NULL,
  correlation_id UUID NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_audit_log_occurred_at ON audit_log(occurred_at);
CREATE INDEX IF NOT EXISTS idx_audit_log_action ON audit_log(action);
CREATE INDEX IF NOT EXISTS idx_audit_log_actor ON audit_log(actor_user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_org ON audit_log(organization_id);
