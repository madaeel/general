package auth

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/bkplane/vespucci/internal/audit"
	"github.com/bkplane/vespucci/internal/httpx"
)

type Deps struct {
	Auth struct {
		// Authenticate returns user and ok
		Authenticate func(email, password string) (struct{ ID [16]byte }, bool)
	}
	Sessions interface {
		Issue(c *gin.Context, userID [16]byte) error
	}
	Audit *audit.Service
}

func LoginHandler(deps *Deps) gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			Email    string `json:"email"`
			Password string `json:"password"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid_request", "message": "Invalid request"})
		 return
		}

		user, ok := deps.Auth.Authenticate(req.Email, req.Password)
		if !ok {
			httpx.NeutralAuthError(c)
			_ = deps.Audit.Write(c.Request.Context(), audit.Entry{
				Action: audit.ActionLoginFailed,
				Metadata: map[string]any{"email": redactEmail(req.Email)},
				IP: strPtr(c.ClientIP()), UserAgent: strPtr(c.Request.UserAgent()),
				Route: strPtr(c.FullPath()), Method: strPtr(c.Request.Method),
			})
			return
		}

		if err := deps.Sessions.Issue(c, user.ID); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error":"server_error","message":"Could not create session"})
			return
		}

		_ = deps.Audit.Write(c.Request.Context(), audit.Entry{
			Action:      audit.ActionLoginSucceeded,
			ActorUserID: &user.ID,
			IP:          strPtr(c.ClientIP()), UserAgent: strPtr(c.Request.UserAgent()),
			Route:       strPtr(c.FullPath()), Method: strPtr(c.Request.Method),
		})

		c.JSON(http.StatusOK, gin.H{"ok": true})
	}
}

func strPtr(s string) *string { return &s }

func redactEmail(e string) string {
	for i := 0; i < len(e); i++ {
		if e[i] == '@' {
			return "***" + e[i:]
		}
	}
	return "***"
}
