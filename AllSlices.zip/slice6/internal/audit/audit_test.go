package audit

import (
	"context"
	"testing"

	"github.com/google/uuid"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func TestWriteAuditLog(t *testing.T) {
	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	if err := db.Exec(`CREATE TABLE audit_log (
		id TEXT PRIMARY KEY,
		occurred_at TIMESTAMP NOT NULL,
		action TEXT NOT NULL,
		actor_user_id TEXT NULL,
		organization_id TEXT NULL,
		ip TEXT NULL,
		user_agent TEXT NULL,
		route TEXT NULL,
		method TEXT NULL,
		correlation_id TEXT NULL,
		metadata JSON NOT NULL
	)`).Error; err != nil {
		t.Fatalf("create table: %v", err)
	}
	s := &Service{DB: db}
	ip := "127.0.0.1"
	ua := "test"
	route := "/auth/login"
	method := "POST"
	uid := uuid.New()
	err = s.Write(context.Background(), Entry{
		Action:      ActionLoginSucceeded,
		ActorUserID: &uid, IP: &ip, UserAgent: &ua, Route: &route, Method: &method,
		Metadata: map[string]any{"ok": true},
	})
	if err != nil {
		t.Fatalf("write: %v", err)
	}
	var count int64
	if err := db.Table("audit_log").Count(&count).Error; err != nil {
		t.Fatalf("count: %v", err)
	}
	if count != 1 {
		t.Fatalf("expected 1 row, got %d", count)
	}
}
