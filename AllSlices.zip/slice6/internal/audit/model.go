package audit

import (
	"context"
	"time"

	"github.com/google/uuid"
	"gorm.io/datatypes"
	"gorm.io/gorm"
)

type Action string

const (
	ActionLoginSucceeded         Action = "login_succeeded"
	ActionLoginFailed            Action = "login_failed"
	ActionLogout                 Action = "logout"
	ActionRegisterRequested      Action = "register_requested"
	ActionRegisterCompleted      Action = "register_completed"
	ActionPasswordResetReq       Action = "password_reset_requested"
	ActionPasswordResetCompleted Action = "password_reset_completed"
	ActionInviteCreated          Action = "invite_created"
	ActionInviteAccepted         Action = "invite_accepted"
	ActionSocialLinked           Action = "social_linked"
	ActionSocialUnlinked         Action = "social_unlinked"
	ActionProviderCallbackFailed Action = "provider_callback_failed"
	ActionSessionRevoked         Action = "session_revoked"
	ActionTokenConsumed          Action = "token_consumed"
	ActionRateLimitBlocked       Action = "rate_limit_blocked"
	ActionCSRFBlocked            Action = "csrf_blocked"
)

type Log struct {
	ID             uuid.UUID      `gorm:"type:uuid;default:gen_random_uuid();primaryKey"`
	OccurredAt     time.Time      `gorm:"autoCreateTime"`
	Action         Action         `gorm:"type:audit_action;not null"`
	ActorUserID    *uuid.UUID     `gorm:"type:uuid"`
	OrganizationID *uuid.UUID     `gorm:"type:uuid"`
	IP             *string
	UserAgent      *string
	Route          *string
	Method         *string
	CorrelationID  *uuid.UUID     `gorm:"type:uuid"`
	Metadata       datatypes.JSON `gorm:"type:jsonb;default:'{}'::jsonb"`
}

func (Log) TableName() string { return "audit_log" }

type Service struct {
	DB *gorm.DB
}

type Entry struct {
	Action         Action
	ActorUserID    *uuid.UUID
	OrganizationID *uuid.UUID
	IP             *string
	UserAgent      *string
	Route          *string
	Method         *string
	CorrelationID  *uuid.UUID
	Metadata       map[string]any
}

func (s *Service) Write(ctx context.Context, e Entry) error {
	meta := datatypes.JSONMap{}
	for k, v := range e.Metadata {
		meta[k] = v
	}
	l := Log{
		Action:         e.Action,
		ActorUserID:    e.ActorUserID,
		OrganizationID: e.OrganizationID,
		IP:             e.IP,
		UserAgent:      e.UserAgent,
		Route:          e.Route,
		Method:         e.Method,
		CorrelationID:  e.CorrelationID,
		Metadata:       datatypes.JSON(meta),
	}
	return s.DB.WithContext(ctx).Create(&l).Error
}
