package httpx

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// NeutralAuthError returns an enumeration-safe error for auth failures.
func NeutralAuthError(c *gin.Context) {
	c.JSON(http.StatusUnauthorized, gin.H{
		"error":         "invalid_credentials",
		"message":       "Invalid credentials",
		"correlationId": c.GetString("correlation_id"),
	})
}
