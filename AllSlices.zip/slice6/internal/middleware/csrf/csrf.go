package csrf

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

type Config struct {
	HeaderName               string
	EnforceOnMethods         []string
	DoubleSubmitCookieName   string
	RequireDoubleSubmitMatch bool
	OnBlocked                func(c *gin.Context)
}

func Middleware(cfg Config) gin.HandlerFunc {
	header := cfg.HeaderName
	if header == "" {
		header = "X-CSRF-Token"
	}
	methods := map[string]struct{}{}
	if len(cfg.EnforceOnMethods) == 0 {
		cfg.EnforceOnMethods = []string{"POST", "PUT", "PATCH", "DELETE"}
	}
	for _, m := range cfg.EnforceOnMethods {
		methods[strings.ToUpper(m)] = struct{}{} }
	return func(c *gin.Context) {
		if _, ok := methods[c.Request.Method]; !ok {
			c.Next()
			return
		}
		token := c.GetHeader(header)
		if token == "" {
			block(c, cfg)
			return
		}
		if cfg.RequireDoubleSubmitMatch && cfg.DoubleSubmitCookieName != "" {
			cookie, err := c.Cookie(cfg.DoubleSubmitCookieName)
			if err != nil || cookie == "" || cookie != token {
				block(c, cfg)
				return
			}
		}
		c.Next()
	}
}

func block(c *gin.Context, cfg Config) {
	if cfg.OnBlocked != nil {
		cfg.OnBlocked(c)
	}
	c.JSON(http.StatusForbidden, gin.H{
		"error":         "invalid_request",
		"message":       "Request blocked",
		"correlationId": c.GetString("correlation_id"),
	})
	c.Abort()
}
