package csrf

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
)

func TestCSRFBlocksMissingHeader(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(Middleware(Config{}))
	r.POST("/mutate", func(c *gin.Context) { c.String(200, "ok") })
	req := httptest.NewRequest("POST", "/mutate", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	if w.Code != http.StatusForbidden {
		t.Fatalf("expected 403, got %d", w.Code)
	}
}

func TestCSRFAcceptsWithHeader(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(Middleware(Config{}))
	r.POST("/mutate", func(c *gin.Context) { c.String(200, "ok") })
	req := httptest.NewRequest("POST", "/mutate", nil)
	req.Header.Set("X-CSRF-Token", "t")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}
}
