package ratelimit

import (
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
)

type limiter struct {
	tokens       int
	capacity     int
	refillEvery  time.Duration
	lastRefilled time.Time
}

type key struct {
	ip    string
	route string
}

type Config struct {
	DefaultPerMinute int
	Routes           map[string]int
	OnBlocked        func(c *gin.Context)
}

type Store struct {
	mu       sync.Mutex
	buckets  map[key]*limiter
	cfg      Config
	nowFunc  func() time.Time
	clientIP func(*http.Request) string
}

func New(cfg Config) *Store {
	if cfg.DefaultPerMinute <= 0 {
		cfg.DefaultPerMinute = 30
	}
	return &Store{
		buckets: make(map[key]*limiter),
		cfg:     cfg,
		nowFunc: time.Now,
		clientIP: func(r *http.Request) string {
			xff := r.Header.Get("X-Forwarded-For")
			if xff != "" {
				parts := strings.Split(xff, ",")
				return strings.TrimSpace(parts[0])
			}
			host, _, err := net.SplitHostPort(r.RemoteAddr)
			if err == nil {
				return host
			}
			return r.RemoteAddr
		},
	}
}

func (s *Store) Middleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		route := c.FullPath()
		if route == "" {
			route = c.Request.URL.Path
		}
		routeKey := c.Request.Method + ":" + route
		limit := s.cfg.Routes[routeKey]
		if limit <= 0 {
			limit = s.cfg.Routes[c.Request.Method+":*"]
		}
		if limit <= 0 {
			limit = s.cfg.DefaultPerMinute
		}
		k := key{ip: s.clientIP(c.Request), route: routeKey}
		now := s.nowFunc()

		s.mu.Lock()
		b, ok := s.buckets[k]
		if !ok {
			b = &limiter{tokens: limit, capacity: limit, refillEvery: time.Minute, lastRefilled: now}
			s.buckets[k] = b
		}
		elapsed := now.Sub(b.lastRefilled)
		if elapsed >= b.refillEvery {
			refills := int(elapsed / b.refillEvery)
			b.tokens = min(b.capacity, b.tokens+refills*limit)
			b.lastRefilled = now
		}
		allowed := b.tokens > 0
		if allowed {
			b.tokens--
		}
		s.mu.Unlock()

		if !allowed {
			if s.cfg.OnBlocked != nil {
				s.cfg.OnBlocked(c)
			}
			c.JSON(http.StatusTooManyRequests, gin.H{
				"error":         "rate_limited",
				"message":       "Request rate limit exceeded, try again later",
				"correlationId": c.GetString("correlation_id"),
			})
			c.Abort()
			return
		}
		c.Next()
	}
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
