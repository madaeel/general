package ratelimit

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
)

func TestRateLimitBlocksAfterThreshold(t *testing.T) {
	gin.SetMode(gin.TestMode)
	rl := New(Config{DefaultPerMinute: 2})
	rl.nowFunc = func() time.Time { return time.Unix(0, 0) }
	r := gin.New()
	// ensure FullPath available
	r.GET("/ping", func(c *gin.Context) { c.String(200, "ok") })
	r.Use(rl.Middleware())

	req := httptest.NewRequest("GET", "/ping", nil)
	w1 := httptest.NewRecorder()
	r.ServeHTTP(w1, req)
	if w1.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w1.Code)
	}
	w2 := httptest.NewRecorder()
	r.ServeHTTP(w2, req)
	if w2.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w2.Code)
	}
	w3 := httptest.NewRecorder()
	r.ServeHTTP(w3, req)
	if w3.Code != http.StatusTooManyRequests {
		t.Fatalf("expected 429, got %d", w3.Code)
	}
}
