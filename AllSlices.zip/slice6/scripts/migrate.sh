#!/usr/bin/env bash
set -euo pipefail

# Minimal migration runner that applies *.up.sql in this slice.
# Usage:
#   DATABASE_URL="postgres://user:pass@host:5432/dbname?sslmode=require" ./scripts/migrate.sh up
#   DATABASE_URL="..." ./scripts/migrate.sh down   # rolls back this slice only

ACTION="${1:-up}"
SLICE_PREFIX="20250903_120001_create_audit_log"

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "DATABASE_URL is required" >&2
  exit 1
fi

case "$ACTION" in
  up)
    psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "db/migrations/${SLICE_PREFIX}.up.sql"
    ;;
  down)
    psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "db/migrations/${SLICE_PREFIX}.down.sql"
    ;;
  *)
    echo "unknown action: $ACTION" >&2
    exit 1
    ;;
esac
