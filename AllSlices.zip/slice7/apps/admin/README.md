# Vespucci Admin UI

This is a minimal React + Vite + Tailwind admin interface for the Identity and Auth MVP.

Endpoints used match the OpenAPI 3.1 spec. Cookies are sent with credentials and an `X-CSRF-Token` header is added when a readable CSRF cookie is present. For social login, the app calls `/auth/{provider}/authorize?redirect=<front-end-callback>` and then POSTS `/auth/{provider}/callback` with `code` and `state` on the callback page. For linking a provider, the app sets a small flag in `localStorage` to include `link: true` in the callback payload.

Environment

- copy `.env.example` to `.env.local` and set `VITE_API_BASE_URL`
- If your backend exposes a readable CSRF cookie name, set `VITE_CSRF_COOKIE`

Local commands

```sh
cd apps/admin
npm install
npm run dev
npm run build
npm run test
```

Notes

- All requests use `fetch` with `credentials: include`.
- Error messages are enumeration safe. The UI shows generic messages for 401 on login.
- To protect routes, see `src/lib/auth.tsx` and `src/routes.tsx`.
- OAuth redirect URIs: set each provider app to redirect back to the front-end callback route, then the SPA posts `code` and `state` to the API:
  - Google/Facebook Authorized redirect: `https://<admin-host>/auth/callback/google` and `/auth/callback/facebook`
  - The front-end builds these from `window.location.origin` when starting `GET /auth/{provider}/authorize?redirect=<callback>`.
- CSRF header: the client forwards `X-CSRF-Token` if a readable cookie is available. If your backend uses HttpOnly CSRF cookies only, expose a non-mutating endpoint that returns a token in JSON and set `VITE_CSRF_COOKIE` accordingly, or relax CSRF for same-site, cookie-only session endpoints during MVP. Do not change OpenAPI paths without updating the spec.
