import { Link } from 'react-router-dom'
import RoutesView from './routes'
import { AuthProvider, useAuth } from './lib/auth'
import { apiFetch } from './lib/api'
import Button from './components/Button'

function Navbar() {
  const { me, refresh } = useAuth()
  const logout = async () => {
    try {
      await apiFetch<void>('/auth/logout', { method: 'POST' })
    } finally {
      await refresh()
    }
  }
  return (
    <nav className="w-full border-b px-4 py-2 flex items-center justify-between">
      <div className="font-semibold">Vespucci Admin</div>
      <div className="flex gap-4">
        {me ? (
          <>
            <Link to="/account/profile" className="hover:underline">Profile</Link>
            <Link to="/account/sessions" className="hover:underline">Sessions</Link>
            <Button onClick={logout}>Logout</Button>
          </>
        ) : (
          <>
            <Link to="/auth/login" className="hover:underline">Login</Link>
            <Link to="/auth/register" className="hover:underline">Register</Link>
          </>
        )}
      </div>
    </nav>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50 text-gray-900">
        <Navbar />
        <main className="max-w-3xl mx-auto p-4">
          <RoutesView />
        </main>
      </div>
    </AuthProvider>
  )
}
