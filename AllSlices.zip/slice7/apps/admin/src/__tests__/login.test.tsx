import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import Login from '../pages/Login'
import * as api from '../lib/api'

vi.mock('../lib/api', async (orig) => {
  const actual: any = await orig()
  return {
    ...actual,
    apiFetch: vi.fn()
  }
})

function renderWithRouter() {
  return render(
    <MemoryRouter>
      <Login />
    </MemoryRouter>
  )
}

describe('Login', () => {
  it('submits credentials', async () => {
    const spy = vi.spyOn(api, 'apiFetch' as any).mockResolvedValue({ ok: true })
    renderWithRouter()
    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'a@b.com' } })
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'pw' } })
    fireEvent.click(screen.getByRole('button', { name: /login/i }))
    await waitFor(() => expect(spy).toHaveBeenCalled())
  })
})
