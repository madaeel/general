import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import Login from '../pages/Login'
import * as api from '../lib/api'

vi.mock('../lib/api', async (orig) => {
  const actual: any = await orig()
  return {
    ...actual,
    apiFetch: vi.fn()
  }
})

describe('Login error handling', () => {
  it('shows enumeration-safe message on 401', async () => {
    const { ApiError } = await import('../lib/api')
    vi.spyOn(api, 'apiFetch' as any).mockRejectedValue(
      new ApiError(401, { error: 'unauthorized', message: 'wrong creds' })
    )
    render(
      <MemoryRouter>
        <Login />
      </MemoryRouter>
    )
    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'a@b.com' } })
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'pw' } })
    fireEvent.click(screen.getByRole('button', { name: /login/i }))
    await waitFor(() => {
      expect(screen.getByText(/invalid email or password/i)).toBeInTheDocument()
    })
  })
})
