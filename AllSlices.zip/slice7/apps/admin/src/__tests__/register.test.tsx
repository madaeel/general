import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import Register from '../pages/Register'
import * as api from '../lib/api'

vi.mock('../lib/api', async (orig) => {
  const actual: any = await orig()
  return {
    ...actual,
    apiFetch: vi.fn()
  }
})

describe('Register', () => {
  it('sends registration payload', async () => {
    const spy = vi.spyOn(api, 'apiFetch' as any).mockResolvedValue({ ok: true })
    render(
      <MemoryRouter>
        <Register />
      </MemoryRouter>
    )
    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'a@b.com' } })
    fireEvent.change(screen.getByLabelText('Given name'), { target: { value: 'Ada' } })
    fireEvent.change(screen.getByLabelText('Family name'), { target: { value: 'Pease' } })
    fireEvent.click(screen.getByRole('button', { name: /register/i }))
    await waitFor(() => expect(spy).toHaveBeenCalled())
  })
})
