type Props = {
  children: React.ReactNode
  variant?: 'info' | 'success' | 'warning' | 'error'
}

export default function Alert({ children, variant = 'warning' }: Props) {
  const styles: Record<string, string> = {
    info: 'border-blue-300 bg-blue-50 text-blue-900',
    success: 'border-green-300 bg-green-50 text-green-900',
    warning: 'border-yellow-300 bg-yellow-50 text-yellow-900',
    error: 'border-red-300 bg-red-50 text-red-900'
  }
  return (
    <div className={`rounded-lg border px-3 py-2 ${styles[variant]}`}>
      {children}
    </div>
  )
}
