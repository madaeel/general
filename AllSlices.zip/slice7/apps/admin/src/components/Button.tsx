type Props = React.ButtonHTMLAttributes<HTMLButtonElement>

export default function Button({ children, ...rest }: Props) {
  return (
    <button
      className="rounded-xl px-4 py-2 shadow bg-black text-white disabled:opacity-60"
      {...rest}
    >
      {children}
    </button>
  )
}
