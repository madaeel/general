import { useId } from 'react'

type Props = React.InputHTMLAttributes<HTMLInputElement> & {
  label: string
  error?: string
}

export default function TextInput({ label, error, ...rest }: Props) {
  const id = useId()
  return (
    <div className="flex flex-col gap-1">
      <label htmlFor={id} className="text-sm">{label}</label>
      <input
        id={id}
        className="border rounded-lg px-3 py-2 focus:outline-none focus:ring w-full"
        {...rest}
      />
      {error ? <div className="text-sm text-red-600">{error}</div> : null}
    </div>
  )
}
