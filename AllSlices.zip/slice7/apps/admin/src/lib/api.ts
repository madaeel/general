import type { ErrorResponse } from './types'

const API_BASE = import.meta.env.VITE_API_BASE_URL || ''
const CSRF_COOKIE = import.meta.env.VITE_CSRF_COOKIE || 'vespucci_csrf'

function getCookie(name: string): string | null {
  const m = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)')
  return m ? decodeURIComponent(m.pop()!) : null
}

export class ApiError extends Error {
  status: number
  body?: ErrorResponse
  constructor(status: number, body?: ErrorResponse) {
    super(body?.message || 'request_failed')
    this.status = status
    this.body = body
  }
}

export async function apiFetch<T>(
  path: string,
  opts: RequestInit = {}
): Promise<T> {
  const headers = new Headers(opts.headers || {})
  if (!(opts.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json')
  }
  const csrf = getCookie(CSRF_COOKIE)
  if (csrf) headers.set('X-CSRF-Token', csrf)

  const res = await fetch(API_BASE + path, {
    ...opts,
    headers,
    credentials: 'include'
  })

  const isJson = res.headers.get('content-type')?.includes('application/json')
  const data = isJson ? await res.json().catch(() => undefined) : undefined

  if (!res.ok) {
    throw new ApiError(res.status, data as ErrorResponse | undefined)
  }
  return data as T
}
