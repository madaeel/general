import React, { createContext, useContext, useEffect, useState } from 'react'
import type { MeResponse } from './types'
import { apiFetch } from './api'

type AuthContextValue = {
  me: MeResponse | null
  loading: boolean
  refresh: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue>({
  me: null,
  loading: true,
  refresh: async () => {}
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [me, setMe] = useState<MeResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const load = async () => {
    setLoading(true)
    try {
      const m = await apiFetch<MeResponse>('/me', { method: 'GET' })
      setMe(m)
    } catch {
      setMe(null)
    } finally {
      setLoading(false)
    }
  }
  useEffect(() => {
    void load()
  }, [])
  return (
    <AuthContext.Provider
      value={{
        me,
        loading,
        refresh: load
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
