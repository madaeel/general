export type ErrorResponse = {
  error: string
  message: string
  correlationId?: string
}

export type TokenEnvelope = { ok: boolean }

export type User = {
  id: string
  email: string
  emailVerifiedAt?: string | null
  givenName?: string
  familyName?: string
  hasPassword: boolean
  createdAt: string
  updatedAt: string
}

export type Organization = {
  id: string
  name: string
  slug?: string
  orgType: 'agency' | 'enterprise' | 'consortium'
  createdAt: string
  updatedAt: string
}

export type Membership = {
  id: string
  userId: string
  organizationId: string
  role: 'owner' | 'admin' | 'agent' | 'viewer'
  status: 'pending' | 'active' | 'disabled'
  joinedAt?: string | null
  leftAt?: string | null
}

export type MeResponse = {
  user: User
  membership: Membership
  organization: Organization
  affiliations?: Array<{
    id: string
    relation: 'enterprise' | 'consortium'
    organization: Organization
  }>
}

export type Session = {
  id: string
  userId: string
  deviceLabel?: string | null
  userAgent?: string | null
  ip?: string | null
  lastSeenAt?: string | null
  expiresAt: string
  revokedAt?: string | null
}

export type SocialIdentity = {
  id: string
  userId: string
  provider: 'google' | 'facebook'
  providerUserId: string
  emailAtLogin?: string | null
  claims?: Record<string, unknown>
  linkedAt: string
}

export type Config = {
  magicLinkLoginEnabled: boolean
  socialProvidersEnabled: Array<'google' | 'facebook'>
  sessionDays: number
}
