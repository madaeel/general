import { useEffect } from 'react'
import { useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { apiFetch, ApiError } from '../lib/api'
import type { TokenEnvelope } from '../lib/types'
import { useAuth } from '../lib/auth'

export default function AuthCallback() {
  const { provider } = useParams()
  const [params] = useSearchParams()
  const code = params.get('code')
  const state = params.get('state')
  const nav = useNavigate()
  const { refresh } = useAuth()

  useEffect(() => {
    const run = async () => {
      const linkIntended = localStorage.getItem('vespucci_oauth_link') === 'true'
      localStorage.removeItem('vespucci_oauth_link')
      try {
        await apiFetch<TokenEnvelope>(`/auth/${provider}/callback`, {
          method: 'POST',
          body: JSON.stringify({ code, state, link: linkIntended || undefined })
        })
        await refresh()
        nav(linkIntended ? '/account/profile' : '/account/profile')
      } catch (err) {
        if (err instanceof ApiError) {
          alert(err.body?.message || 'Authentication failed')
        } else {
          alert('Authentication failed')
        }
        nav('/auth/login')
      }
    }
    void run()
  }, [])

  return <div>Completing sign in...</div>
}
