import { useState } from 'react'
import TextInput from '../components/TextInput'
import Button from '../components/Button'
import { apiFetch, ApiError } from '../lib/api'
import type { TokenEnvelope } from '../lib/types'
import Alert from '../components/Alert'

export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [ok, setOk] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      await apiFetch<TokenEnvelope>('/auth/password/forgot', {
        method: 'POST',
        body: JSON.stringify({ email })
      })
      setOk(true)
    } catch (err) {
      if (err instanceof ApiError) setError(err.body?.message || 'Request failed')
      else setError('Request failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <h1 className="text-xl mb-4">Forgot password</h1>
      {ok ? <Alert variant="success">If the account exists, a reset email has been sent.</Alert> : null}
      {error ? <Alert variant="error">{error}</Alert> : null}
      <form className="flex flex-col gap-3" onSubmit={submit}>
        <TextInput label="Email" type="email" value={email} onChange={e => setEmail(e.target.value)} required />
        <Button disabled={loading}>{loading ? 'Sending...' : 'Send reset email'}</Button>
      </form>
    </div>
  )
}
