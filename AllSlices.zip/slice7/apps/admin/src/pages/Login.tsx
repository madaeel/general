import { useState } from 'react'
import TextInput from '../components/TextInput'
import Button from '../components/Button'
import { apiFetch, ApiError } from '../lib/api'
import type { TokenEnvelope } from '../lib/types'
import { Link, useNavigate } from 'react-router-dom'
import Alert from '../components/Alert'
import { useAuth } from '../lib/auth'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const nav = useNavigate()
  const { refresh } = useAuth()

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      await apiFetch<TokenEnvelope>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      })
      await refresh()
      nav('/account/profile')
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.status === 401 ? 'Invalid email or password' : err.body?.message || 'Login failed')
      } else {
        setError('Login failed')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <h1 className="text-xl mb-4">Login</h1>
      {error ? <Alert variant="error">{error}</Alert> : null}
      <form className="flex flex-col gap-3" onSubmit={submit}>
        <TextInput label="Email" type="email" value={email} onChange={e => setEmail(e.target.value)} required />
        <TextInput label="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} required />
        <div className="flex gap-2 items-center">
          <Button disabled={loading}>{loading ? 'Loading...' : 'Login'}</Button>
          <Link to="/auth/forgot" className="text-sm underline">Forgot password</Link>
        </div>
      </form>
      <div className="mt-4 text-sm">
        No account yet? <Link to="/auth/register" className="underline">Register</Link>
      </div>
    </div>
  )
}
