import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import TextInput from '../components/TextInput'
import Button from '../components/Button'
import Alert from '../components/Alert'
import { apiFetch, ApiError } from '../lib/api'
import type { TokenEnvelope } from '../lib/types'
import { useAuth } from '../lib/auth'

export default function MagicLinkConsume() {
  const [params] = useSearchParams()
  const token = params.get('token') || ''
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const nav = useNavigate()
  const { refresh } = useAuth()

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      await apiFetch<TokenEnvelope>('/auth/magic-link-consume', {
        method: 'POST',
        body: JSON.stringify({ token, password })
      })
      await refresh()
      nav('/account/profile')
    } catch (err) {
      if (err instanceof ApiError) setError(err.body?.message || 'Unable to set password')
      else setError('Unable to set password')
    } finally {
      setLoading(false)
    }
  }
  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <h1 className="text-xl mb-4">Set your password</h1>
      {error ? <Alert variant="error">{error}</Alert> : null}
      <form className="flex flex-col gap-3" onSubmit={submit}>
        <TextInput label="New password" type="password" minLength={12} value={password} onChange={e => setPassword(e.target.value)} required />
        <Button disabled={loading}>{loading ? 'Saving...' : 'Save and continue'}</Button>
      </form>
    </div>
  )
}
