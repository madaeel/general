import { useEffect, useMemo, useState } from 'react'
import { useAuth } from '../lib/auth'
import { apiFetch, ApiError } from '../lib/api'
import type { Config, SocialIdentity } from '../lib/types'
import Button from '../components/Button'
import Alert from '../components/Alert'

export default function Profile() {
  const { me, refresh } = useAuth()
  const [config, setConfig] = useState<Config | null>(null)
  const [linked, setLinked] = useState<SocialIdentity[]>([])
  const [error, setError] = useState<string | null>(null)

  const load = async () => {
    try {
      const [cfg, ids] = await Promise.all([
        apiFetch<Config>('/config', { method: 'GET' }),
        apiFetch<SocialIdentity[]>('/me/social-identities', { method: 'GET' })
      ])
      setConfig(cfg)
      setLinked(ids)
    } catch (err) {
      if (err instanceof ApiError) setError(err.body?.message || 'Failed to load profile')
      else setError('Failed to load profile')
    }
  }

  useEffect(() => {
    void load()
  }, [])

  const providerSet = useMemo(() => new Set(linked.map(i => i.provider)), [linked])
  const canUnlink = (prov: 'google' | 'facebook') => {
    const others = linked.filter(i => i.provider !== prov).length
    return me?.user.hasPassword || others > 0
  }

  const beginLink = (provider: 'google' | 'facebook') => {
    localStorage.setItem('vespucci_oauth_link', 'true')
    const origin = window.location.origin
    const callback = `${origin}/auth/callback/${provider}`
    window.location.href = `${import.meta.env.VITE_API_BASE_URL || ''}/auth/${provider}/authorize?redirect=${encodeURIComponent(callback)}`
  }

  const unlink = async (provider: 'google' | 'facebook') => {
    if (!canUnlink(provider)) {
      setError('You need a password or another linked provider to unlink this one')
      return
    }
    try {
      await apiFetch<void>(`/auth/${provider}/unlink`, { method: 'POST' })
      await load()
      await refresh()
    } catch (err) {
      if (err instanceof ApiError) setError(err.body?.message || 'Failed to unlink provider')
      else setError('Failed to unlink provider')
    }
  }

  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <h1 className="text-xl mb-4">Profile</h1>
      {error ? <Alert variant="error">{error}</Alert> : null}
      <div className="mb-4">
        <div className="text-sm text-gray-600">Signed in as</div>
        <div className="font-medium">{me?.user.email}</div>
      </div>
      <h2 className="text-lg mt-4 mb-2">Connected accounts</h2>
      <div className="flex gap-2 mb-3">
        {config?.socialProvidersEnabled?.map(p => (
          providerSet.has(p)
            ? <Button key={p} onClick={() => unlink(p)}>Unlink {p}</Button>
            : <Button key={p} onClick={() => beginLink(p)}>Link {p}</Button>
        ))}
      </div>
    </div>
  )
}
