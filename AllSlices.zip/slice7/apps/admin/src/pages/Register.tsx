import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import TextInput from '../components/TextInput'
import Button from '../components/Button'
import { apiFetch, ApiError } from '../lib/api'
import type { TokenEnvelope } from '../lib/types'
import Alert from '../components/Alert'

export default function Register() {
  const [params] = useSearchParams()
  const inviteToken = params.get('inviteToken')
  const [email, setEmail] = useState('')
  const [givenName, setGivenName] = useState('')
  const [familyName, setFamilyName] = useState('')
  const [sent, setSent] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const nav = useNavigate()

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      await apiFetch<TokenEnvelope>('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ email, givenName, familyName, inviteToken })
      })
      setSent(true)
    } catch (err) {
      if (err instanceof ApiError) setError(err.body?.message || 'Registration failed')
      else setError('Registration failed')
    } finally {
      setLoading(false)
    }
  }

  if (sent) {
    return (
      <div className="bg-white rounded-2xl shadow p-6">
        <h1 className="text-xl mb-4">Check your email</h1>
        <p>We sent a magic link to set your password. If it does not arrive, you can request another one.</p>
        <div className="mt-4">
          <Button onClick={() => nav('/auth/magic-link')}>Request another magic link</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <h1 className="text-xl mb-4">Register</h1>
      {error ? <Alert variant="error">{error}</Alert> : null}
      <form className="flex flex-col gap-3" onSubmit={submit}>
        <TextInput label="Email" type="email" value={email} onChange={e => setEmail(e.target.value)} required />
        <div className="grid grid-cols-2 gap-3">
          <TextInput label="Given name" value={givenName} onChange={e => setGivenName(e.target.value)} required />
          <TextInput label="Family name" value={familyName} onChange={e => setFamilyName(e.target.value)} required />
        </div>
        <Button disabled={loading}>{loading ? 'Sending...' : 'Register'}</Button>
      </form>
    </div>
  )
}
