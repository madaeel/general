import { useEffect, useState } from 'react'
import { apiFetch, ApiError } from '../lib/api'
import type { Session } from '../lib/types'
import Alert from '../components/Alert'
import Button from '../components/Button'

export default function Sessions() {
  const [sessions, setSessions] = useState<Session[]>([])
  const [error, setError] = useState<string | null>(null)
  const load = async () => {
    try {
      const res = await apiFetch<{ sessions: Session[] }>('/sessions', { method: 'GET' })
      setSessions(res.sessions)
    } catch (err) {
      if (err instanceof ApiError) setError(err.body?.message || 'Failed to load sessions')
      else setError('Failed to load sessions')
    }
  }
  const revoke = async (id: string) => {
    try {
      await apiFetch<void>(`/sessions/${id}/revoke`, { method: 'POST' })
      await load()
    } catch (err) {
      if (err instanceof ApiError) setError(err.body?.message || 'Failed to revoke session')
      else setError('Failed to revoke session')
    }
  }
  useEffect(() => { void load() }, [])
  return (
    <div className="bg-white rounded-2xl shadow p-6">
      <h1 className="text-xl mb-4">Your sessions</h1>
      {error ? <Alert variant="error">{error}</Alert> : null}
      <ul className="divide-y">
        {sessions.map(s => (
          <li key={s.id} className="py-3 flex items-center justify-between">
            <div>
              <div className="font-medium">{s.deviceLabel || s.userAgent || 'Device'}</div>
              <div className="text-sm text-gray-600">Expires {new Date(s.expiresAt).toLocaleString()}</div>
            </div>
            <Button onClick={() => revoke(s.id)}>Revoke</Button>
          </li>
        ))}
      </ul>
    </div>
  )
}
