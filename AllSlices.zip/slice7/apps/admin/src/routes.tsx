import { Route, Routes, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import MagicLinkRequest from './pages/MagicLinkRequest'
import MagicLinkConsume from './pages/MagicLinkConsume'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import Sessions from './pages/Sessions'
import Profile from './pages/Profile'
import AuthCallback from './pages/AuthCallback'
import { useAuth } from './lib/auth'

function Protected({ children }: { children: JSX.Element }) {
  const { me, loading } = useAuth()
  if (loading) return <div>Loading...</div>
  if (!me) return <Navigate to="/auth/login" replace />
  return children
}

export default function RoutesView() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/auth/login" />} />
      <Route path="/auth/login" element={<Login />} />
      <Route path="/auth/register" element={<Register />} />
      <Route path="/auth/magic-link" element={<MagicLinkRequest />} />
      <Route path="/auth/magic-link/consume" element={<MagicLinkConsume />} />
      <Route path="/auth/forgot" element={<ForgotPassword />} />
      <Route path="/auth/reset" element={<ResetPassword />} />
      <Route path="/auth/callback/:provider" element={<AuthCallback />} />
      <Route path="/account/sessions" element={<Protected><Sessions /></Protected>} />
      <Route path="/account/profile" element={<Protected><Profile /></Protected>} />
    </Routes>
  )
}
