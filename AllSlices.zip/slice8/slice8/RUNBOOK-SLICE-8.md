Slice 8 – CI, Docker, Terraform stubs

Local verification
- Go tests
  - if go.mod exists: go test ./... -count=1 -race -timeout=5m
- UI build
  - if package.json in repo root: npm ci && npm run build
  - or if apps/admin/package.json: cd apps/admin && npm ci && npm run build
- Docker
  - make docker-api
  - make docker-ui
- Terraform
  - cd infra/terraform
  - cp envs/dev/terraform.tfvars.example terraform.tfvars
  - terraform init
  - terraform validate
  - terraform plan -var-file=terraform.tfvars

CI overview
- .github/workflows/ci.yml runs go vet/test, builds UI, then builds and pushes images to GHCR on main.
- Images will be named:
  - ghcr.io/${repo}-api:<sha|tag>
  - ghcr.io/${repo}-ui:<sha|tag>

Secrets & config placeholders
- GitHub Actions
  - Uses GITHUB_TOKEN for GHCR push by default.
- AWS
  - Configure AWS creds for Terraform runs later, not included in this slice.
- Secrets Manager keys suggested:
  - /vespucci/<env>/database/url
  - /vespucci/<env>/postmark/api_key
  - /vespucci/<env>/oauth/google/client_id, client_secret
  - /vespucci/<env>/oauth/facebook/app_id, app_secret

Risks
- Paths for API main package assumed at ./cmd/api; adjust Dockerfile.api if different.
- Monorepo variations for admin UI handled, but verify your actual paths.
- GHCR package visibility may require org settings.

Next slice proposal
- Wire ECS Fargate task definitions, ALB, and RDS module skeletons.
- Add environment-specific GitHub Environments with OIDC to assume AWS role for Terraform apply.
