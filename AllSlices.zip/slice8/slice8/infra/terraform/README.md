# Terraform stubs for Vespucci (Slice 8)

Purpose
- Provide initial Terraform scaffolding for AWS deployment using ECS Fargate, RDS PostgreSQL, and AWS Secrets Manager.
- Separate environments: dev, stg, prod.

Layout
- infra/terraform/main.tf           # providers, backend, and module wiring (stubs)
- infra/terraform/variables.tf      # common variables
- infra/terraform/outputs.tf        # common outputs
- infra/terraform/envs/<env>/       # remote state backends and tfvars examples

Prereqs
- Terraform >= 1.6
- AWS credentials available in environment, or via SSO profile.
- Backing S3 bucket and DynamoDB table for state locking created out-of-band.

Quickstart
1) Choose an environment, e.g. dev:
   cd infra/terraform
   cp envs/dev/terraform.tfvars.example terraform.tfvars
   terraform init
   terraform validate
   terraform plan

Secrets and configuration
- Do not hardcode secrets. Use AWS Secrets Manager:
  - /vespucci/<env>/database/url
  - /vespucci/<env>/postmark/api_key
  - /vespucci/<env>/oauth/google/client_id
  - /vespucci/<env>/oauth/google/client_secret
  - /vespucci/<env>/oauth/facebook/app_id
  - /vespucci/<env>/oauth/facebook/app_secret

Next steps
- Replace placeholders with real module sources.
- Add ECS service and task definitions for:
  - API image ghcr.io/bkplane/vespucci-api:<tag>
  - UI image  ghcr.io/bkplane/vespucci-ui:<tag>
